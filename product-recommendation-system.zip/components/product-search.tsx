"use client"

import type React from "react"

import { useState, useCallback, memo } from "react"
import { Search, Coffee } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import type { Product } from "@/lib/types"

interface ProductSearchProps {
  products: Product[]
  onProductSelect: (product: Product) => void
}

// Use memo to prevent unnecessary re-renders
const ProductSearch = memo(function ProductSearch({ products, onProductSelect }: ProductSearchProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Product[]>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault()
      setIsSearching(true)

      if (!searchQuery.trim()) {
        setSearchResults([])
        setIsSearching(false)
        return
      }

      // Simulate search delay
      const timer = setTimeout(() => {
        const results = products.filter((product) => {
          const searchLower = searchQuery.toLowerCase()
          return (
            product.title.toLowerCase().includes(searchLower) ||
            product.description.toLowerCase().includes(searchLower) ||
            product.category.toLowerCase().includes(searchLower)
          )
        })
        setSearchResults(results)
        setIsSearching(false)
      }, 500)

      return () => clearTimeout(timer)
    },
    [searchQuery, products],
  )

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Coffee Product Finder</h1>
        <p className="text-lg text-muted-foreground">
          Describe what you're looking for, and we'll find the perfect coffee products for you
        </p>
      </div>

      <Card className="border-2">
        <CardContent className="pt-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <Input
                className="pl-10 py-6 text-lg"
                placeholder="What kind of coffee product are you looking for?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
            </div>
            <Button type="submit" className="w-full py-6 text-lg" size="lg" disabled={isSearching}>
              {isSearching ? "Searching..." : "Find Products"}
            </Button>
          </form>

          {searchResults.length > 0 && (
            <div className="mt-6 space-y-4">
              <h2 className="text-xl font-semibold">Search Results</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {searchResults.map((product) => (
                  <Card
                    key={product.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => onProductSelect(product)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <Coffee className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium line-clamp-1">{product.title}</h3>
                          <p className="text-sm text-muted-foreground">{product.category}</p>
                        </div>
                      </div>
                      <p className="mt-2 text-sm line-clamp-2">{product.description}</p>
                      <div className="mt-3 flex justify-between items-center">
                        <span className="font-bold">{product.price}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation()
                            onProductSelect(product)
                          }}
                        >
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
})

export default ProductSearch

