import type { Product } from "@/lib/types"
import DetailedProductImage from "@/components/detailed-product-image"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

interface FeaturedProductsProps {
  products: Product[]
}

export default function FeaturedProducts({ products }: FeaturedProductsProps) {
  // Get one product from each category
  const categories = ["Hard Goods", "Cleaning products", "Syrups", "Services"]
  const featuredProducts = categories
    .map((category) => products.find((p) => p.category === category))
    .filter(Boolean) as Product[]

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6 text-center">Featured Products</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {featuredProducts.map((product) => (
          <div key={product.id} className="group relative overflow-hidden rounded-lg">
            <DetailedProductImage
              product={product}
              className="h-64 w-full transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-4">
              <h3 className="text-white font-bold">{product.title}</h3>
              <p className="text-white/80 text-sm mb-2">{product.category}</p>
              <Button variant="outline" className="bg-white text-black hover:bg-white/90 w-full">
                View Details
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

