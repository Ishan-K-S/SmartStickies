import { Coffee, Droplet, Wrench, Sparkles } from "lucide-react"
import type { Product } from "@/lib/types"

interface ProductImageProps {
  product: Product
  className?: string
}

export default function ProductImage({ product, className = "" }: ProductImageProps) {
  // Generate a deterministic color based on the product ID
  const generateColor = (id: string) => {
    let hash = 0
    for (let i = 0; i < id.length; i++) {
      hash = id.charCodeAt(i) + ((hash << 5) - hash)
    }

    // Different hue ranges for different categories
    let hue = 0
    switch (product.category) {
      case "Hard Goods":
        hue = (hash % 60) + 20 // browns and reds (20-80)
        break
      case "Cleaning products":
        hue = (hash % 60) + 180 // blues (180-240)
        break
      case "Syrups":
        hue = (hash % 60) + 300 // purples and pinks (300-360)
        break
      case "Services":
        hue = (hash % 60) + 100 // greens and yellows (100-160)
        break
      default:
        hue = hash % 360
    }

    // Saturation and lightness based on product ID
    const saturation = 70 + (hash % 30)
    const lightness = 45 + (hash % 20)

    return `hsl(${hue}, ${saturation}%, ${lightness}%)`
  }

  // Get icon based on category
  const getIcon = () => {
    switch (product.category) {
      case "Hard Goods":
        return <Coffee className="h-12 w-12 text-white opacity-80" />
      case "Cleaning products":
        return <Droplet className="h-12 w-12 text-white opacity-80" />
      case "Syrups":
        return <Sparkles className="h-12 w-12 text-white opacity-80" />
      case "Services":
        return <Wrench className="h-12 w-12 text-white opacity-80" />
      default:
        return <Coffee className="h-12 w-12 text-white opacity-80" />
    }
  }

  // Generate a pattern for the background
  const generatePattern = (id: string) => {
    const patternId = `pattern-${id}`
    const baseColor = generateColor(id)
    const darkerColor = baseColor.replace("lightness", Number.parseFloat(baseColor.split("%")[1]) - 10 + "%")

    // Different patterns for different categories
    let pattern
    switch (product.category) {
      case "Hard Goods":
        pattern = (
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20" patternTransform="rotate(45)">
            <rect width="20" height="20" fill={baseColor} />
            <rect width="10" height="10" fill={darkerColor} />
          </pattern>
        )
        break
      case "Cleaning products":
        pattern = (
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20">
            <rect width="20" height="20" fill={baseColor} />
            <circle cx="10" cy="10" r="5" fill={darkerColor} />
          </pattern>
        )
        break
      case "Syrups":
        pattern = (
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20">
            <rect width="20" height="20" fill={baseColor} />
            <path d="M0,10 L20,10 M10,0 L10,20" stroke={darkerColor} strokeWidth="2" />
          </pattern>
        )
        break
      case "Services":
        pattern = (
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20" patternTransform="rotate(30)">
            <rect width="20" height="20" fill={baseColor} />
            <rect x="0" y="0" width="10" height="10" fill={darkerColor} />
            <rect x="10" y="10" width="10" height="10" fill={darkerColor} />
          </pattern>
        )
        break
      default:
        pattern = (
          <pattern id={patternId} patternUnits="userSpaceOnUse" width="20" height="20">
            <rect width="20" height="20" fill={baseColor} />
          </pattern>
        )
    }

    return { pattern, patternId }
  }

  const { pattern, patternId } = generatePattern(product.id)
  const backgroundColor = generateColor(product.id)

  return (
    <div className={`relative overflow-hidden rounded-md ${className}`}>
      <svg className="w-full h-full absolute inset-0" xmlns="http://www.w3.org/2000/svg">
        <defs>{pattern}</defs>
        <rect width="100%" height="100%" fill={`url(#${patternId})`} />
      </svg>

      <div className="absolute inset-0 flex items-center justify-center">{getIcon()}</div>

      <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 p-2 text-white text-xs font-medium truncate">
        {product.title}
      </div>
    </div>
  )
}

