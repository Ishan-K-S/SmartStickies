"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { Product } from "@/lib/types"
import ProductCard from "@/components/product-card"
import { Loader2 } from "lucide-react"

interface ProductRecommenderProps {
  products: Product[]
}

export default function ProductRecommender({ products }: ProductRecommenderProps) {
  const [query, setQuery] = useState("")
  const [priceRange, setPriceRange] = useState("all")
  const [coffeeType, setCoffeeType] = useState("all")
  const [isOrganic, setIsOrganic] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [recommendations, setRecommendations] = useState<Product[] | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call delay
    setTimeout(() => {
      const filteredProducts = getRecommendations()
      setRecommendations(filteredProducts)
      setIsLoading(false)
    }, 1000)
  }

  const getRecommendations = (): Product[] => {
    // Filter products based on user preferences
    let filtered = [...products]

    // Filter by price range
    if (priceRange !== "all") {
      const [min, max] = priceRange.split("-").map(Number)
      filtered = filtered.filter((p) => {
        const price = Number.parseFloat(p.price.toString().replace("$", ""))
        return price >= min && (max ? price <= max : true)
      })
    }

    // Filter by coffee type
    if (coffeeType !== "all") {
      if (coffeeType === "arabica") {
        filtered = filtered.filter(
          (p) => p.title.toLowerCase().includes("arabica") || p.description.toLowerCase().includes("arabica"),
        )
      } else if (coffeeType === "robusta") {
        filtered = filtered.filter(
          (p) => p.title.toLowerCase().includes("robusta") || p.description.toLowerCase().includes("robusta"),
        )
      } else if (coffeeType === "blend") {
        filtered = filtered.filter(
          (p) => p.title.toLowerCase().includes("blend") || p.description.toLowerCase().includes("blend"),
        )
      }
    }

    // Filter by organic
    if (isOrganic) {
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes("organic") ||
          p.title.toLowerCase().includes("bio") ||
          p.description.toLowerCase().includes("organic") ||
          p.description.toLowerCase().includes("bio"),
      )
    }

    // Filter by query text
    if (query) {
      const queryTerms = query.toLowerCase().split(" ")
      filtered = filtered.filter((p) => {
        const productText = `${p.title} ${p.description}`.toLowerCase()
        return queryTerms.some((term) => productText.includes(term))
      })
    }

    // Sort by relevance (category: Hard Goods first)
    filtered.sort((a, b) => {
      if (a.category === "Hard Goods" && b.category !== "Hard Goods") return -1
      if (a.category !== "Hard Goods" && b.category === "Hard Goods") return 1
      return 0
    })

    // Limit to top 6 recommendations
    return filtered.slice(0, 6)
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="query">What are you looking for?</Label>
          <Textarea
            id="query"
            placeholder="E.g., I want a rich, dark roast coffee with chocolate notes"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="min-h-[100px]"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="price-range">Price Range</Label>
            <Select value={priceRange} onValueChange={setPriceRange}>
              <SelectTrigger id="price-range">
                <SelectValue placeholder="Select price range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any Price</SelectItem>
                <SelectItem value="0-25">Under $25</SelectItem>
                <SelectItem value="25-50">$25 - $50</SelectItem>
                <SelectItem value="50-100">$50 - $100</SelectItem>
                <SelectItem value="100-">Over $100</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="coffee-type">Coffee Type</Label>
            <Select value={coffeeType} onValueChange={setCoffeeType}>
              <SelectTrigger id="coffee-type">
                <SelectValue placeholder="Select coffee type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any Type</SelectItem>
                <SelectItem value="arabica">Arabica</SelectItem>
                <SelectItem value="robusta">Robusta</SelectItem>
                <SelectItem value="blend">Blend</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox id="organic" checked={isOrganic} onCheckedChange={(checked) => setIsOrganic(checked === true)} />
          <Label htmlFor="organic" className="cursor-pointer">
            Organic/Bio Only
          </Label>
        </div>

        <Button type="submit" disabled={isLoading} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Finding products...
            </>
          ) : (
            "Get Recommendations"
          )}
        </Button>
      </form>

      {recommendations && recommendations.length > 0 && (
        <div className="mt-6 space-y-4">
          <h3 className="text-lg font-semibold">Recommended Products:</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}

      {recommendations && recommendations.length === 0 && (
        <div className="p-4 bg-yellow-50 text-yellow-600 rounded-md mt-6">
          No products found matching your preferences. Try adjusting your filters.
        </div>
      )}
    </div>
  )
}

