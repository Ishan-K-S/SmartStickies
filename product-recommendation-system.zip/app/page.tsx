"use client"

import { useState, useCallback } from "react"
import ProductSearch from "@/components/product-search"
import PopularProducts from "@/components/popular-products"
import ProductCategories from "@/components/product-categories"
import ProductDetailModal from "@/components/product-detail-modal"
import { coffeeProducts } from "@/lib/product-data"
import type { Product } from "@/lib/types"
import { RecentlyViewedProvider } from "@/contexts/recently-viewed-context"

export default function Home() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // Calculate category counts once
  const categories = Array.from(new Set(coffeeProducts.map((p) => p.category))).map((category) => ({
    name: category,
    count: coffeeProducts.filter((p) => p.category === category).length,
  }))

  // Memoize handlers to prevent recreating them on every render
  const handleProductSelect = useCallback((product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }, [])

  const handleCategorySelect = useCallback((category: string) => {
    // In a real app, this would filter products by category
    console.log(`Category selected: ${category}`)
  }, [])

  const handleModalClose = useCallback(() => {
    setIsModalOpen(false)
  }, [])

  return (
    <RecentlyViewedProvider>
      <main className="min-h-screen bg-gray-50">
        <div className="container mx-auto py-10 px-4">
          <ProductSearch products={coffeeProducts} onProductSelect={handleProductSelect} />

          <ProductCategories categories={categories} onCategorySelect={handleCategorySelect} />

          <PopularProducts products={coffeeProducts} onProductSelect={handleProductSelect} />

          <ProductDetailModal product={selectedProduct} isOpen={isModalOpen} onClose={handleModalClose} />
        </div>
      </main>
    </RecentlyViewedProvider>
  )
}

