"use server"

import fs from "fs/promises"
import path from "path"
import type { Product, EmbeddingResult } from "./types"
import { generateEmbedding } from "./embedding-service"

// Mock data path - in a real app, this would be a database
const DATA_FILE = path.join(process.cwd(), "data", "products.json")

// Load products from the data file
export async function loadProducts(): Promise<Product[]> {
  try {
    // Check if the data directory and file exist
    try {
      await fs.access(path.join(process.cwd(), "data"))
    } catch {
      // Create the data directory if it doesn't exist
      await fs.mkdir(path.join(process.cwd(), "data"), { recursive: true })

      // Create a sample products file if it doesn't exist
      await fs.writeFile(DATA_FILE, JSON.stringify(getSampleProducts(), null, 2))
    }

    try {
      await fs.access(DATA_FILE)
    } catch {
      // Create a sample products file if it doesn't exist
      await fs.writeFile(DATA_FILE, JSON.stringify(getSampleProducts(), null, 2))
    }

    // Read the products file
    const data = await fs.readFile(DATA_FILE, "utf-8")
    return JSON.parse(data) as Product[]
  } catch (error) {
    console.error("Error loading products:", error)
    // Return sample data as fallback
    return getSampleProducts()
  }
}

// Search for similar products based on a query
export async function searchSimilarProducts(query: string, limit = 5): Promise<Product[]> {
  try {
    // Load all products
    const products = await loadProducts()

    // Generate embedding for the query
    const queryEmbedding = await generateEmbedding(query)

    // Generate embeddings for all products (in a real app, these would be pre-computed)
    const productEmbeddings: EmbeddingResult[] = await Promise.all(
      products.map(async (product) => {
        const text = `${product.title} ${product.description} ${product.category || ""}`
        const embedding = await generateEmbedding(text)
        return { id: product.id, embedding, product }
      }),
    )

    // Calculate cosine similarity between query and each product
    const similarities = productEmbeddings.map((item) => {
      const similarity = calculateCosineSimilarity(queryEmbedding, item.embedding)
      return { product: item.product, similarity }
    })

    // Sort by similarity (highest first) and take the top results
    const topResults = similarities
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map((item) => item.product)

    return topResults
  } catch (error) {
    console.error("Error searching similar products:", error)
    throw new Error("Failed to search for similar products")
  }
}

// Calculate cosine similarity between two vectors
function calculateCosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) {
    throw new Error("Vectors must have the same length")
  }

  let dotProduct = 0
  let normA = 0
  let normB = 0

  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i]
    normA += a[i] * a[i]
    normB += b[i] * b[i]
  }

  normA = Math.sqrt(normA)
  normB = Math.sqrt(normB)

  if (normA === 0 || normB === 0) {
    return 0
  }

  return dotProduct / (normA * normB)
}

// Generate sample products for testing
function getSampleProducts(): Product[] {
  return [
    {
      id: "P1001",
      title: "UltraBook Pro X1",
      description:
        "Powerful laptop with 16GB RAM, 512GB SSD, and 12-hour battery life. Perfect for professionals and students who need performance on the go.",
      price: 1299.99,
      category: "Electronics",
    },
    {
      id: "P1002",
      title: "PowerCore 20000mAh Battery Pack",
      description:
        "High-capacity portable charger with fast charging technology. Can charge most smartphones up to 5 times on a single charge.",
      price: 49.99,
      category: "Electronics",
    },
    {
      id: "P1003",
      title: "ErgoDesk Standing Desk",
      description:
        "Adjustable height desk with electric motor. Smooth transition between sitting and standing positions for better ergonomics.",
      price: 349.99,
      category: "Furniture",
    },
    {
      id: "P1004",
      title: "CloudComfort Memory Foam Pillow",
      description:
        "Premium memory foam pillow that adapts to your sleeping position. Provides excellent neck support for a restful night's sleep.",
      price: 59.99,
      category: "Bedding",
    },
    {
      id: "P1005",
      title: "FitTrack Smart Watch",
      description:
        "Fitness tracker with heart rate monitoring, sleep tracking, and 7-day battery life. Water-resistant and compatible with iOS and Android.",
      price: 129.99,
      category: "Electronics",
    },
    {
      id: "P1006",
      title: "UltraSlim Laptop",
      description:
        "Ultra-portable laptop weighing just 2.2 lbs with 10-hour battery life. Features an Intel Core i5 processor and 8GB RAM.",
      price: 899.99,
      category: "Electronics",
    },
    {
      id: "P1007",
      title: "MaxPower Gaming Laptop",
      description:
        "High-performance gaming laptop with NVIDIA RTX 3080, 32GB RAM, and 1TB SSD. 17-inch display with 144Hz refresh rate.",
      price: 1999.99,
      category: "Electronics",
    },
    {
      id: "P1008",
      title: "BusinessBook Pro",
      description:
        "Business laptop with enhanced security features, 14-inch display, and 16-hour battery life. Includes Microsoft Office subscription.",
      price: 1199.99,
      category: "Electronics",
    },
    {
      id: "P1009",
      title: "EcoCharge Solar Power Bank",
      description:
        "Environmentally friendly 10000mAh power bank with solar charging capability. Perfect for camping and outdoor activities.",
      price: 39.99,
      category: "Electronics",
    },
    {
      id: "P1010",
      title: "HomeOffice Ergonomic Chair",
      description:
        "Fully adjustable office chair with lumbar support, headrest, and breathable mesh back. Designed for all-day comfort.",
      price: 249.99,
      category: "Furniture",
    },
  ]
}

