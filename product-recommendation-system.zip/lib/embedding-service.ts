"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Generate embeddings using the OpenAI API
export async function generateEmbedding(text: string): Promise<number[]> {
  try {
    // Use OpenAI's embedding model through the AI SDK
    const { text: embeddingText } = await generateText({
      model: openai("gpt-4o"),
      prompt: `
        Convert the following text into a numerical embedding representation.
        The embedding should be a JSON array of 1536 floating point numbers.
        Only return the JSON array, nothing else.
        
        Text: "${text}"
      `,
    })

    try {
      // Extract the JSON array from the response
      const jsonStart = embeddingText.indexOf("[")
      const jsonEnd = embeddingText.lastIndexOf("]") + 1

      if (jsonStart >= 0 && jsonEnd > jsonStart) {
        const jsonStr = embeddingText.substring(jsonStart, jsonEnd)
        return JSON.parse(jsonStr)
      }
    } catch (parseError) {
      console.error("Error parsing embedding:", parseError)
    }

    // Fallback to a simple embedding function if parsing fails
    return generateSimpleEmbedding(text)
  } catch (error) {
    console.error("Error generating embedding:", error)

    // Fallback to a simple embedding function if the API call fails
    return generateSimpleEmbedding(text)
  }
}

// A simple fallback embedding function
function generateSimpleEmbedding(text: string): number[] {
  // This is a very naive implementation just for fallback
  // It creates a 1536-dimensional vector (same as OpenAI's ada-002)
  // with values based on character frequencies

  const charFreq = new Map<string, number>()
  for (const char of text.toLowerCase()) {
    charFreq.set(char, (charFreq.get(char) || 0) + 1)
  }

  // Create a sparse vector of size 1536
  const embedding = new Array(1536).fill(0)

  // Fill some positions based on character frequencies
  let position = 0
  for (const [char, freq] of charFreq.entries()) {
    const code = char.charCodeAt(0)
    position = (code * 11) % 1536
    embedding[position] = freq / text.length
  }

  // Normalize the vector
  const norm = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0))
  if (norm > 0) {
    for (let i = 0; i < embedding.length; i++) {
      embedding[i] /= norm
    }
  }

  return embedding
}

