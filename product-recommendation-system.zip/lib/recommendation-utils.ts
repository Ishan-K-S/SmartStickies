import type { Product } from "@/lib/types"

/**
 * Calculate similarity score between two products
 * Higher score means more similar
 */
export function calculateProductSimilarity(product1: Product, product2: Product): number {
  if (product1.id === product2.id) return 0 // Don't recommend the same product

  let score = 0

  // Category match is a strong signal
  if (product1.category === product2.category) {
    score += 5
  }

  // Check for common words in titles
  const title1Words = product1.title.toLowerCase().split(/\s+/)
  const title2Words = product2.title.toLowerCase().split(/\s+/)
  const commonTitleWords = title1Words.filter((word) => word.length > 3 && title2Words.includes(word))
  score += commonTitleWords.length * 2

  // Check for common words in descriptions
  const desc1Words = product1.description.toLowerCase().split(/\s+/)
  const desc2Words = product2.description.toLowerCase().split(/\s+/)
  const commonDescWords = desc1Words.filter((word) => word.length > 3 && desc2Words.includes(word))
  score += commonDescWords.length * 0.5

  // Price similarity (closer prices get higher score)
  const price1 =
    typeof product1.price === "string" ? Number.parseFloat(product1.price.replace(/[^0-9.]/g, "")) : product1.price
  const price2 =
    typeof product2.price === "string" ? Number.parseFloat(product2.price.replace(/[^0-9.]/g, "")) : product2.price

  const priceDiff = Math.abs(price1 - price2)
  if (priceDiff < 10) score += 3
  else if (priceDiff < 25) score += 2
  else if (priceDiff < 50) score += 1

  return score
}

/**
 * Find related products based on similarity
 */
export function findRelatedProducts(currentProduct: Product, allProducts: Product[], limit = 3): Product[] {
  // Calculate similarity scores
  const productsWithScores = allProducts
    .map((product) => ({
      product,
      score: calculateProductSimilarity(currentProduct, product),
    }))
    .filter((item) => item.score > 0) // Only include products with some similarity
    .sort((a, b) => b.score - a.score) // Sort by score (highest first)

  // Return top N products
  return productsWithScores.slice(0, limit).map((item) => item.product)
}

/**
 * Find complementary products that pair well with the current product
 */
export function findComplementaryProducts(currentProduct: Product, allProducts: Product[], limit = 2): Product[] {
  // For coffee products, recommend cleaning products or syrups
  if (currentProduct.category === "Hard Goods") {
    return allProducts
      .filter((p) => p.id !== currentProduct.id && (p.category === "Cleaning products" || p.category === "Syrups"))
      .slice(0, limit)
  }

  // For cleaning products, recommend coffee products
  if (currentProduct.category === "Cleaning products") {
    return allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Hard Goods").slice(0, limit)
  }

  // For syrups, recommend coffee products
  if (currentProduct.category === "Syrups") {
    return allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Hard Goods").slice(0, limit)
  }

  // For services, recommend other services or coffee products
  if (currentProduct.category === "Services") {
    const otherServices = allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Services").slice(0, 1)

    const coffeeProducts = allProducts.filter((p) => p.category === "Hard Goods").slice(0, limit - otherServices.length)

    return [...otherServices, ...coffeeProducts]
  }

  // Default fallback
  return allProducts.filter((p) => p.id !== currentProduct.id).slice(0, limit)
}

/**
 * Create a context-aware recommendation based on multiple factors
 */
export function getContextualRecommendations(
  currentProduct: Product,
  allProducts: Product[],
  recentlyViewed: Product[] = [],
  limit = 4,
): Product[] {
  // Get products similar to recently viewed items
  const recentBasedRecs =
    recentlyViewed.length > 0
      ? recentlyViewed.flatMap((p) => findRelatedProducts(p, allProducts, 2)).filter((p) => p.id !== currentProduct.id)
      : []

  // Get products similar to current product
  const similarProducts = findRelatedProducts(currentProduct, allProducts, limit)

  // Combine and deduplicate
  const combinedRecs = [...recentBasedRecs, ...similarProducts]
  const uniqueRecs = Array.from(new Map(combinedRecs.map((p) => [p.id, p])).values())

  return uniqueRecs.slice(0, limit)
}

