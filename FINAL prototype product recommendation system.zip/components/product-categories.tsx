"use client"

import type React from "react"

import { Coffee, Droplet, Sparkles, Wrench } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface CategoryProps {
  icon: React.ReactNode
  name: string
  count: number
  onClick: () => void
}

function Category({ icon, name, count, onClick }: CategoryProps) {
  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={onClick}>
      <CardContent className="p-4 flex items-center gap-4">
        <div className="bg-primary/10 p-3 rounded-full">{icon}</div>
        <div>
          <h3 className="font-medium">{name}</h3>
          <p className="text-sm text-muted-foreground">{count} products</p>
        </div>
      </CardContent>
    </Card>
  )
}

interface ProductCategoriesProps {
  categories: { name: string; count: number }[]
  onCategorySelect: (category: string) => void
}

export default function ProductCategories({ categories, onCategorySelect }: ProductCategoriesProps) {
  const getCategoryIcon = (name: string) => {
    switch (name) {
      case "Hard Goods":
        return <Coffee className="h-5 w-5 text-primary" />
      case "Cleaning products":
        return <Droplet className="h-5 w-5 text-primary" />
      case "Syrups":
        return <Sparkles className="h-5 w-5 text-primary" />
      case "Services":
        return <Wrench className="h-5 w-5 text-primary" />
      default:
        return <Coffee className="h-5 w-5 text-primary" />
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto mt-12">
      <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {categories.map((category) => (
          <Category
            key={category.name}
            icon={getCategoryIcon(category.name)}
            name={category.name}
            count={category.count}
            onClick={() => onCategorySelect(category.name)}
          />
        ))}
      </div>
    </div>
  )
}

