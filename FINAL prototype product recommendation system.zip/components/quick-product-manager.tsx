"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useInventory } from "@/contexts/inventory-context"
import { generateProductCode, createUniversalLink } from "@/lib/product-utils"
import { Check, Copy, ExternalLink } from "lucide-react"
import { useProducts } from "@/contexts/product-context"

export default function QuickProductManager() {
  const { updateInventory } = useInventory()
  const { addProduct } = useProducts()
  const [newProduct, setNewProduct] = useState({
    title: "",
    description: "",
    price: "",
    category: "Hard Goods",
    stock: "10",
  })
  const [productId, setProductId] = useState("")
  const [productCode, setProductCode] = useState("")
  const [productLink, setProductLink] = useState("")
  const [copied, setCopied] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewProduct((prev) => ({ ...prev, [name]: value }))
  }

  const handleCategoryChange = (value: string) => {
    setNewProduct((prev) => ({ ...prev, category: value }))
  }

  const handleAddProduct = () => {
    // Generate a new product ID
    const categoryPrefix = newProduct.category.toLowerCase().replace(/\s+/g, "-")
    const timestamp = Date.now().toString().slice(-6)
    const newId = `${categoryPrefix}-${timestamp}`

    // Generate product code
    const index = Math.floor(Math.random() * 999) // For demo purposes
    const code = generateProductCode({ ...newProduct, id: newId, category: newProduct.category } as any, index)

    // Generate product link
    const link = createUniversalLink(code, window.location.origin)

    // Create the new product object
    const product = {
      id: newId,
      title: newProduct.title,
      description: newProduct.description,
      price: newProduct.price.startsWith("$") ? newProduct.price : `$${newProduct.price}`,
      category: newProduct.category,
    }

    // Add to global products
    addProduct(product)

    // Add to inventory
    const stock = Number.parseInt(newProduct.stock)
    if (!isNaN(stock) && stock >= 0) {
      updateInventory(newId, stock)
    }

    // Update state
    setProductId(newId)
    setProductCode(code)
    setProductLink(link)
    setSuccess(true)

    // In a real app, you would save the new product to your database
    console.log("New product added:", {
      id: newId,
      title: newProduct.title,
      description: newProduct.description,
      price: newProduct.price.startsWith("$") ? newProduct.price : `$${newProduct.price}`,
      category: newProduct.category,
      stock,
    })

    // Reset form after a delay
    setTimeout(() => {
      setSuccess(false)
      setNewProduct({
        title: "",
        description: "",
        price: "",
        category: "Hard Goods",
        stock: "10",
      })
    }, 5000)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(productLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Quick Product Manager</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Product Name</Label>
          <Input
            id="title"
            name="title"
            placeholder="Premium Coffee Blend"
            value={newProduct.title}
            onChange={handleInputChange}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            name="description"
            placeholder="A rich, aromatic blend..."
            value={newProduct.description}
            onChange={handleInputChange}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="price">Price</Label>
            <Input id="price" name="price" placeholder="29.99" value={newProduct.price} onChange={handleInputChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={newProduct.category} onValueChange={handleCategoryChange}>
              <SelectTrigger id="category">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Hard Goods">Hard Goods</SelectItem>
                <SelectItem value="Cleaning products">Cleaning products</SelectItem>
                <SelectItem value="Syrups">Syrups</SelectItem>
                <SelectItem value="Services">Services</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="stock">Initial Stock</Label>
          <Input
            id="stock"
            name="stock"
            type="number"
            min="0"
            placeholder="10"
            value={newProduct.stock}
            onChange={handleInputChange}
          />
        </div>

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-md p-4 space-y-3">
            <div className="flex items-center text-green-700">
              <Check className="h-5 w-5 mr-2" />
              <span className="font-medium">Product added successfully!</span>
            </div>

            <div className="space-y-2 text-sm">
              <div>
                <span className="font-medium">Product ID:</span> {productId}
              </div>
              <div>
                <span className="font-medium">Product Code:</span> {productCode}
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Product Link:</span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="h-7 px-2" onClick={copyToClipboard}>
                    {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 px-2"
                    onClick={() => window.open(productLink, "_blank")}
                  >
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          onClick={handleAddProduct}
          disabled={!newProduct.title || !newProduct.price || !newProduct.category}
        >
          Add Product & Generate Link
        </Button>
      </CardFooter>
    </Card>
  )
}

