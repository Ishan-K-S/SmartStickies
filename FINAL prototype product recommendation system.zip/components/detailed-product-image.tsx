import type { Product } from "@/lib/types"

interface DetailedProductImageProps {
  product: Product
  className?: string
}

export default function DetailedProductImage({ product, className = "" }: DetailedProductImageProps) {
  // Generate a deterministic color based on the product ID
  const generateColor = (id: string, shift = 0) => {
    let hash = 0
    for (let i = 0; i < id.length; i++) {
      hash = id.charCodeAt(i) + ((hash << 5) - hash)
    }

    // Different hue ranges for different categories
    let hue = 0
    switch (product.category) {
      case "Hard Goods":
        hue = (hash % 60) + 20 + shift // browns and reds (20-80)
        break
      case "Cleaning products":
        hue = (hash % 60) + 180 + shift // blues (180-240)
        break
      case "Syrups":
        hue = (hash % 60) + 300 + shift // purples and pinks (300-360)
        break
      case "Services":
        hue = (hash % 60) + 100 + shift // greens and yellows (100-160)
        break
      default:
        hue = (hash % 360) + shift
    }

    // Saturation and lightness based on product ID
    const saturation = 70 + (hash % 30)
    const lightness = 45 + (hash % 20)

    return `hsl(${hue}, ${saturation}%, ${lightness}%)`
  }

  // Get detailed SVG illustration based on category and product title
  const getDetailedIllustration = () => {
    const primaryColor = generateColor(product.id)
    const secondaryColor = generateColor(product.id, 30)
    const accentColor = generateColor(product.id, -30)

    // Check if product is coffee related
    const isCoffee =
      product.category === "Hard Goods" &&
      (product.title.toLowerCase().includes("coffee") || product.description.toLowerCase().includes("coffee"))

    // Check if product is espresso related
    const isEspresso =
      product.title.toLowerCase().includes("espresso") || product.description.toLowerCase().includes("espresso")

    // Check if product is chocolate related
    const isChocolate =
      product.title.toLowerCase().includes("chocolate") || product.description.toLowerCase().includes("chocolate")

    // Check if product is vanilla related
    const isVanilla =
      product.title.toLowerCase().includes("vanilla") || product.description.toLowerCase().includes("vanilla")

    // Check if product is caramel related
    const isCaramel =
      product.title.toLowerCase().includes("caramel") || product.description.toLowerCase().includes("caramel")

    // Check if product is hazelnut related
    const isHazelnut =
      product.title.toLowerCase().includes("hazelnut") || product.description.toLowerCase().includes("hazelnut")

    // Check if product is decaf
    const isDecaf = product.title.toLowerCase().includes("decaf") || product.description.toLowerCase().includes("decaf")

    // Check if product is organic
    const isOrganic =
      product.title.toLowerCase().includes("organic") ||
      product.title.toLowerCase().includes("bio") ||
      product.description.toLowerCase().includes("organic") ||
      product.description.toLowerCase().includes("bio")

    switch (product.category) {
      case "Hard Goods":
        if (isEspresso) {
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id={`espresso-grad-${product.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor={primaryColor} />
                  <stop offset="100%" stopColor={accentColor} />
                </linearGradient>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>

              {/* Espresso machine */}
              <rect
                x="40"
                y="70"
                width="120"
                height="80"
                rx="5"
                fill={primaryColor}
                filter={`url(#shadow-${product.id})`}
              />
              <rect x="50" y="60" width="100" height="15" rx="5" fill={secondaryColor} />
              <rect x="85" y="40" width="30" height="20" rx="2" fill={secondaryColor} />
              <circle cx="100" cy="50" r="5" fill="#fff" />

              {/* Coffee group */}
              <rect x="70" y="85" width="60" height="10" rx="2" fill={accentColor} />
              <path d="M80,95 L80,120 L120,120 L120,95" fill={secondaryColor} />

              {/* Cup */}
              <ellipse cx="100" cy="150" rx="20" ry="5" fill="#333" opacity="0.3" />
              <path d="M85,120 L115,120 L110,150 L90,150 Z" fill="#fff" />
              <path d="M90,125 L110,125 L108,145 L92,145 Z" fill="#6F4E37" />

              {/* Steam */}
              <path d="M95,40 Q90,30 95,20 Q100,10 95,0" stroke="#fff" strokeWidth="2" fill="none" opacity="0.7" />
              <path d="M105,40 Q110,25 105,15 Q100,5 105,0" stroke="#fff" strokeWidth="2" fill="none" opacity="0.7" />

              {/* Label */}
              {isOrganic && (
                <g transform="translate(40, 160)">
                  <rect x="0" y="0" width="120" height="20" rx="10" fill="#4CAF50" />
                  <text x="60" y="15" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                    ORGANIC
                  </text>
                </g>
              )}
              {isDecaf && (
                <g transform="translate(40, 160)">
                  <rect x="0" y="0" width="120" height="20" rx="10" fill="#9C27B0" />
                  <text x="60" y="15" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                    DECAF
                  </text>
                </g>
              )}
            </svg>
          )
        } else if (isChocolate) {
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id={`choc-grad-${product.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#6B4226" />
                  <stop offset="100%" stopColor="#3A2313" />
                </linearGradient>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>

              {/* Chocolate container */}
              <rect
                x="50"
                y="60"
                width="100"
                height="120"
                rx="5"
                fill="#D7CCC8"
                filter={`url(#shadow-${product.id})`}
              />
              <rect x="55" y="65" width="90" height="110" rx="3" fill="#EFEBE9" />

              {/* Chocolate powder */}
              <ellipse cx="100" cy="85" rx="35" ry="15" fill={`url(#choc-grad-${product.id})`} />

              {/* Spoon */}
              <rect x="95" y="40" width="10" height="60" rx="5" fill="#BDBDBD" />
              <ellipse cx="100" cy="100" rx="20" ry="10" fill="#BDBDBD" transform="rotate(-30, 100, 100)" />

              {/* Steam/aroma */}
              <path d="M85,70 Q80,60 85,50 Q90,40 85,30" stroke="#6B4226" strokeWidth="1" fill="none" opacity="0.5" />
              <path
                d="M100,65 Q95,55 100,45 Q105,35 100,25"
                stroke="#6B4226"
                strokeWidth="1"
                fill="none"
                opacity="0.5"
              />
              <path
                d="M115,70 Q120,60 115,50 Q110,40 115,30"
                stroke="#6B4226"
                strokeWidth="1"
                fill="none"
                opacity="0.5"
              />

              {/* Label */}
              <rect x="60" y="130" width="80" height="30" rx="3" fill={primaryColor} />
              <text x="100" y="150" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                CHOCOLATE
              </text>

              {/* Chocolate squares decoration */}
              <rect x="70" y="100" width="15" height="15" rx="2" fill="#5D4037" />
              <rect x="92" y="100" width="15" height="15" rx="2" fill="#5D4037" />
              <rect x="114" y="100" width="15" height="15" rx="2" fill="#5D4037" />
            </svg>
          )
        } else {
          // Default coffee bag
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id={`bag-grad-${product.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor={primaryColor} />
                  <stop offset="100%" stopColor={accentColor} />
                </linearGradient>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>

              {/* Coffee bag */}
              <path
                d="M60,40 L140,40 L150,180 L50,180 Z"
                fill={`url(#bag-grad-${product.id})`}
                filter={`url(#shadow-${product.id})`}
              />

              {/* Top fold */}
              <path d="M60,40 L140,40 L130,20 L70,20 Z" fill={secondaryColor} />

              {/* Label */}
              <rect x="70" y="70" width="60" height="80" rx="5" fill="#fff" opacity="0.9" />

              {/* Coffee beans decoration */}
              <ellipse cx="85" cy="110" rx="10" ry="15" transform="rotate(-30, 85, 110)" fill="#3E2723" />
              <ellipse cx="115" cy="110" rx="10" ry="15" transform="rotate(30, 115, 110)" fill="#3E2723" />
              <ellipse cx="100" cy="130" rx="10" ry="15" fill="#3E2723" />

              {/* Text */}
              <text x="100" y="90" fontSize="10" fontWeight="bold" fill={primaryColor} textAnchor="middle">
                PREMIUM
              </text>
              <text x="100" y="160" fontSize="12" fontWeight="bold" fill="#fff" textAnchor="middle">
                COFFEE
              </text>

              {/* Special labels */}
              {isOrganic && (
                <g transform="translate(130, 60) rotate(30)">
                  <circle cx="0" cy="0" r="15" fill="#4CAF50" />
                  <text x="0" y="4" fontSize="8" fontWeight="bold" fill="white" textAnchor="middle">
                    ORGANIC
                  </text>
                </g>
              )}
              {isDecaf && (
                <g transform="translate(70, 60) rotate(-30)">
                  <circle cx="0" cy="0" r="15" fill="#9C27B0" />
                  <text x="0" y="4" fontSize="8" fontWeight="bold" fill="white" textAnchor="middle">
                    DECAF
                  </text>
                </g>
              )}
            </svg>
          )
        }

      case "Cleaning products":
        return (
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id={`bottle-grad-${product.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={primaryColor} />
                <stop offset="100%" stopColor={accentColor} />
              </linearGradient>
              <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
              </filter>
            </defs>

            {/* Cleaning bottle */}
            <path
              d="M85,40 L115,40 L115,70 L130,90 L130,180 L70,180 L70,90 L85,70 Z"
              fill={`url(#bottle-grad-${product.id})`}
              filter={`url(#shadow-${product.id})`}
            />

            {/* Bottle cap */}
            <rect x="90" y="30" width="20" height="10" rx="2" fill={secondaryColor} />
            <rect x="95" y="20" width="10" height="10" rx="2" fill={secondaryColor} />

            {/* Spray nozzle (if it's a spray bottle) */}
            {product.title.toLowerCase().includes("mfc") && (
              <g>
                <rect x="115" y="35" width="20" height="5" rx="2" fill={secondaryColor} />
                <rect x="130" y="30" width="5" height="15" rx="2" fill={secondaryColor} />
                <circle cx="135" cy="30" r="3" fill={secondaryColor} />
              </g>
            )}

            {/* Label */}
            <rect x="75" y="100" width="50" height="70" rx="3" fill="#fff" opacity="0.9" />

            {/* Bubbles decoration */}
            <circle cx="65" cy="60" r="5" fill="#fff" opacity="0.7" />
            <circle cx="60" cy="70" r="3" fill="#fff" opacity="0.7" />
            <circle cx="70" cy="65" r="4" fill="#fff" opacity="0.7" />
            <circle cx="140" cy="60" r="5" fill="#fff" opacity="0.7" />
            <circle cx="135" cy="70" r="3" fill="#fff" opacity="0.7" />
            <circle cx="145" cy="65" r="4" fill="#fff" opacity="0.7" />

            {/* Text */}
            <text x="100" y="120" fontSize="10" fontWeight="bold" fill={primaryColor} textAnchor="middle">
              CLEANING
            </text>
            <text x="100" y="135" fontSize="8" fill={primaryColor} textAnchor="middle">
              SOLUTION
            </text>

            {/* Product-specific elements */}
            {product.title.toLowerCase().includes("tablet") && (
              <g>
                <rect x="130" y="110" width="20" height="20" rx="2" fill="#fff" />
                <rect x="135" y="115" width="10" height="10" rx="1" fill={primaryColor} />
                <rect x="130" y="140" width="20" height="20" rx="2" fill="#fff" />
                <rect x="135" y="145" width="10" height="10" rx="1" fill={primaryColor} />
              </g>
            )}

            {product.title.toLowerCase().includes("powder") && (
              <g>
                <path d="M130,110 L150,110 L145,130 L135,130 Z" fill="#fff" />
                <ellipse cx="140" cy="130" rx="5" ry="2" fill={primaryColor} opacity="0.7" />
                <path d="M130,140 L150,140 L145,160 L135,160 Z" fill="#fff" />
                <ellipse cx="140" cy="160" rx="5" ry="2" fill={primaryColor} opacity="0.7" />
              </g>
            )}
          </svg>
        )

      case "Syrups":
        // Determine syrup color based on flavor
        let syrupColor = "#9C27B0" // Default purple
        if (isVanilla) syrupColor = "#F5DEB3"
        if (isCaramel) syrupColor = "#D2691E"
        if (isHazelnut) syrupColor = "#8B4513"

        return (
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id={`syrup-grad-${product.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={primaryColor} stopOpacity="0.8" />
                <stop offset="100%" stopColor={accentColor} stopOpacity="0.8" />
              </linearGradient>
              <linearGradient id={`liquid-grad-${product.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={syrupColor} stopOpacity="0.9" />
                <stop offset="100%" stopColor={syrupColor} stopOpacity="0.7" />
              </linearGradient>
              <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
              </filter>
            </defs>

            {/* Syrup bottle */}
            <path
              d="M70,60 L130,60 L125,180 L75,180 Z"
              fill={`url(#syrup-grad-${product.id})`}
              opacity="0.6"
              filter={`url(#shadow-${product.id})`}
            />

            {/* Bottle neck */}
            <path d="M85,60 L115,60 L110,40 L90,40 Z" fill={primaryColor} />

            {/* Bottle cap */}
            <rect x="90" y="30" width="20" height="10" rx="5" fill={secondaryColor} />

            {/* Syrup liquid */}
            <path d="M75,80 L125,80 L120,175 L80,175 Z" fill={`url(#liquid-grad-${product.id})`} />

            {/* Label */}
            <rect x="80" y="100" width="40" height="60" rx="3" fill="#fff" opacity="0.9" />

            {/* Pump top (for syrup bottles) */}
            <rect x="95" y="20" width="10" height="10" rx="5" fill={secondaryColor} />
            <path d="M95,25 L85,25 L85,15 L90,10 L95,15 Z" fill={secondaryColor} />

            {/* Text */}
            <text x="100" y="120" fontSize="8" fontWeight="bold" fill={primaryColor} textAnchor="middle">
              PREMIUM
            </text>
            <text x="100" y="130" fontSize="6" fill={primaryColor} textAnchor="middle">
              SYRUP
            </text>

            {/* Flavor-specific text */}
            {isVanilla && (
              <text x="100" y="145" fontSize="10" fontWeight="bold" fill="#8B4513" textAnchor="middle">
                VANILLA
              </text>
            )}
            {isCaramel && (
              <text x="100" y="145" fontSize="10" fontWeight="bold" fill="#8B4513" textAnchor="middle">
                CARAMEL
              </text>
            )}
            {isHazelnut && (
              <text x="100" y="145" fontSize="10" fontWeight="bold" fill="#8B4513" textAnchor="middle">
                HAZELNUT
              </text>
            )}

            {/* Vegan label */}
            {product.description.toLowerCase().includes("vegan") && (
              <g transform="translate(130, 90) rotate(30)">
                <circle cx="0" cy="0" r="15" fill="#4CAF50" />
                <text x="0" y="4" fontSize="8" fontWeight="bold" fill="white" textAnchor="middle">
                  VEGAN
                </text>
              </g>
            )}
          </svg>
        )

      case "Services":
        // For services, create a scene based on the service type
        if (product.title.toLowerCase().includes("barista")) {
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>
              {/* Barista scene */}
              {/* Counter */}
              <rect x="30" y="120" width="140" height="60" fill="#8D6E63" filter={`url(#shadow-${product.id})`} />
              <rect x="30" y="115" width="140" height="10" fill="#A1887F" />
              {/* Espresso machine */}
              <rect x="40" y="70" width="80" height="45" rx="5" fill="#E0E0E0" />
              <rect x="45" y="60" width="70" height="10" rx="5" fill="#BDBDBD" />
              <rect x="65" y="40" width="30" height="20" rx="2" fill="#BDBDBD" />
              <circle cx="80" cy="50" r="5" fill="#fff" />
              {/* Coffee grinder */}
              <rect x="130" y="80" width="30" height="35" rx="2" fill="#616161" />
              <rect x="135" y="70" width="20" height="10" rx="2" fill="#9E9E9E" />
              <rect x="140" y="60" width="10" height="10" rx="2" fill="#9E9E9E" />
              {/* Barista (simplified) */}
              <circle cx="160" cy="40" r="15" fill="#FFCC80" /> {/* Head */}
              <rect x="150" y="55" width="20" height="30" fill="#4CAF50" /> {/* Torso */}
              <rect x="150" y="85" width="8" height="20" fill="#1976D2" /> {/* Left leg */}
              <rect x="162" y="85" width="8" height="20" fill="#1976D2" /> {/* Right leg */}
              <rect x="145" y="55" width="5" height="20" fill="#FFCC80" /> {/* Left arm */}
              <rect x="170" y="55" width="5" height="20" fill="#FFCC80" /> {/* Right arm */}
              {/* Coffee cup */}
              <path d="M60,130 L90,130 L85,160 L65,160 Z" fill="#fff" />
              <ellipse cx="75" cy="130" rx="15" ry="5" fill="#fff" />
              <path d="M65,135 L85,135 L83,155 L67,155 Z" fill="#795548" />
              {/* Steam */}
              <path d="M70,130 Q65,120 70,110 Q75,100 70,90" stroke="#fff" strokeWidth="2" fill="none" opacity="0.7" />
              <path d="M80,130 Q85,115 80,105 Q75,95 80,85" stroke="#fff" strokeWidth="2" fill="none" opacity="0.7" />
              {/* Text banner */}
              <rect x="30" y="20" width="140" height="20" rx="5" fill={primaryColor} />
              <text x="100" y="35" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                BARISTA TRAINING
              </text>
            </svg>
          )
        } else if (
          product.title.toLowerCase().includes("technical") ||
          product.title.toLowerCase().includes("repair")
        ) {
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>
              {/* Technical repair scene */}
              {/* Workbench */}
              <rect x="30" y="120" width="140" height="10" fill="#8D6E63" filter={`url(#shadow-${product.id})`} />
              <rect x="40" y="130" width="10" height="50" fill="#8D6E63" />
              <rect x="150" y="130" width="10" height="50" fill="#8D6E63" />
              {/* Coffee machine being repaired */}
              <rect x="60" y="70" width="80" height="50" rx="5" fill="#E0E0E0" />
              <rect x="65" y="60" width="70" height="10" rx="5" fill="#BDBDBD" />
              {/* Open panel */}
              <rect x="70" y="80" width="60" height="30" rx="2" fill="#424242" />
              {/* Internal components */}
              <circle cx="85" cy="95" r="5" fill="#F44336" />
              <rect x="95" y="90" width="10" height="10" fill="#2196F3" />
              <rect x="110" y="85" width="5" height="20" fill="#4CAF50" />
              {/* Technician (simplified) */}
              <circle cx="40" cy="60" r="15" fill="#FFCC80" /> {/* Head */}
              <rect x="30" y="75" width="20" height="30" fill="#1976D2" /> {/* Torso */}
              <rect x="30" y="105" width="8" height="15" fill="#424242" /> {/* Left leg */}
              <rect x="42" y="105" width="8" height="15" fill="#424242" /> {/* Right leg */}
              <rect x="50" y="80" width="25" height="5" fill="#FFCC80" /> {/* Right arm extended to machine */}
              <rect x="20" y="85" width="10" height="5" fill="#FFCC80" /> {/* Left arm */}
              {/* Tools */}
              <rect x="75" y="130" width="50" height="10" rx="2" fill="#616161" /> {/* Toolbox */}
              <path d="M130,90 L150,85 L148,88 L128,93 Z" fill="#FFC107" /> {/* Screwdriver */}
              <circle cx="140" cy="130" r="5" fill="#E0E0E0" /> {/* Spare part */}
              <path d="M20,95 L15,105 L25,105 Z" fill="#F44336" /> {/* Warning sign */}
              {/* Text banner */}
              <rect x="30" y="20" width="140" height="20" rx="5" fill={primaryColor} />
              <text x="100" y="35" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                TECHNICAL SERVICE
              </text>
            </svg>
          )
        } else if (
          product.title.toLowerCase().includes("consultation") ||
          product.title.toLowerCase().includes("menu")
        ) {
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
                <linearGradient id={`paper-grad-${product.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#F5F5F5" />
                </linearGradient>
              </defs>
              {/* Consultation scene */}
              {/* Table */}
              <rect x="30" y="120" width="140" height="10" fill="#8D6E63" filter={`url(#shadow-${product.id})`} />
              <rect x="40" y="130" width="10" height="50" fill="#8D6E63" />
              <rect x="150" y="130" width="10" height="50" fill="#8D6E63" />
              {/* Menu/documents */}
              <rect
                x="50"
                y="70"
                width="100"
                height="140"
                rx="2"
                fill={`url(#paper-grad-${product.id})`}
                filter={`url(#shadow-${product.id})`}
              />
              <rect x="60" y="80" width="80" height="5" rx="1" fill="#9E9E9E" />
              <rect x="60" y="90" width="60" height="5" rx="1" fill="#9E9E9E" />
              <rect x="60" y="100" width="70" height="5" rx="1" fill="#9E9E9E" />
              <rect x="60" y="110" width="50" height="5" rx="1" fill="#9E9E9E" />
              {/* Coffee cup */}
              <path d="M160" y="90" width="20" height="30" rx="2" fill="#795548" />
              <ellipse cx="170" cy="90" rx="10" ry="5" fill="#8D6E63" />
              <path d="M165,95 L175,95 L173,115 L167,115 Z" fill="#D7CCC8" />
              {/* Consultant and client (simplified) */}
              <circle cx="30" cy="60" r="10" fill="#FFCC80" /> {/* Consultant head */}
              <rect x="25" y="70" width="10" height="20" fill="#4CAF50" /> {/* Consultant torso */}
              <circle cx="170" cy="60" r="10" fill="#FFCC80" /> {/* Client head */}
              <rect x="165" y="70" width="10" height="20" fill="#1976D2" /> {/* Client torso */}
              {/* Text banner */}
              <rect x="30" y="20" width="140" height="20" rx="5" fill={primaryColor} />
              <text x="100" y="35" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                CONSULTATION
              </text>
            </svg>
          )
        } else {
          // Default service illustration
          return (
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
                </filter>
              </defs>
              {/* Cafe scene */}
              {/* Floor */}
              <rect x="0" y="150" width="200" height="50" fill="#EFEBE9" />
              {/* Counter */}
              <rect x="120" y="70" width="60" height="80" fill="#8D6E63" filter={`url(#shadow-${product.id})`} />
              <rect x="120" y="65" width="60" height="10" fill="#A1887F" />
              {/* Espresso machine on counter */}
              <rect x="130" y="40" width="40" height="25" rx="3" fill="#E0E0E0" />
              <rect x="135" y="35" width="30" height="5" rx="2" fill="#BDBDBD" />
              <circle cx="150" cy="50" r="3" fill="#616161" />
              {/* Tables */}
              <circle cx="40" cy="130" r="20" fill="#A1887F" />
              <rect x="35" y="150" width="10" height="20" fill="#8D6E63" />
              <circle cx="90" cy="140" r="20" fill="#A1887F" />
              <rect x="85" y="160" width="10" height="20" fill="#8D6E63" />
              {/* Coffee cups on tables */}
              <path d="M35,120 L45,120 L43,130 L37,130 Z" fill="#FFFFFF" />
              <path d="M85,130 L95,130 L93,140 L87,140 Z" fill="#FFFFFF" />
              {/* People (simplified) */}
              <circle cx="30" cy="100" r="8" fill="#FFCC80" /> {/* Person 1 head */}
              <rect x="25" y="108" width="10" height="15" fill="#4CAF50" /> {/* Person 1 torso */}
              <circle cx="50" cy="100" r="8" fill="#FFCC80" /> {/* Person 2 head */}
              <rect x="45" y="108" width="10" height="15" fill="#F44336" /> {/* Person 2 torso */}
              <circle cx="80" cy="110" r="8" fill="#FFCC80" /> {/* Person 3 head */}
              <rect x="75" y="118" width="10" height="15" fill="#2196F3" /> {/* Person 3 torso */}
              <circle cx="150" cy="100" r="8" fill="#FFCC80" /> {/* Barista head */}
              <rect x="145" y="108" width="10" height="15" fill="#212121" /> {/* Barista torso */}
              {/* Text banner */}
              <rect x="30" y="20" width="140" height="20" rx="5" fill={primaryColor} />
              <text x="100" y="35" fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                COFFEE SERVICES
              </text>
            </svg>
          )
        }

      default:
        // Generic product image
        return (
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id={`default-grad-${product.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={primaryColor} />
                <stop offset="100%" stopColor={accentColor} />
              </linearGradient>
              <filter id={`shadow-${product.id}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
              </filter>
            </defs>

            <rect
              x="40"
              y="40"
              width="120"
              height="120"
              rx="10"
              fill={`url(#default-grad-${product.id})`}
              filter={`url(#shadow-${product.id})`}
            />
            <text x="100" y="110" fontSize="16" fontWeight="bold" fill="white" textAnchor="middle">
              {product.title.substring(0, 1)}
            </text>
          </svg>
        )
    }
  }

  return (
    <div className={`relative overflow-hidden rounded-md ${className}`}>
      {getDetailedIllustration()}

      <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 p-2 text-white text-xs font-medium truncate">
        {product.title}
      </div>
    </div>
  )
}

