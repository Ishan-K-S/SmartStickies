"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useCart } from "@/contexts/cart-context"
import { ShoppingCart, ArrowRight, X } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useInventory } from "@/contexts/inventory-context"

export default function MiniCart({ onClose }: { onClose?: () => void }) {
  const { items, removeFromCart, subtotal, itemCount } = useCart()
  const { getInventoryCount } = useInventory()

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-6 text-center">
        <ShoppingCart className="h-10 w-10 text-muted-foreground mb-4" />
        <h3 className="font-medium mb-1">Your cart is empty</h3>
        <p className="text-sm text-muted-foreground mb-4">Add items to get started</p>
        <Button variant="outline" size="sm" onClick={onClose}>
          Continue Shopping
        </Button>
      </div>
    )
  }

  return (
    <div className="w-full max-w-sm">
      <div className="flex items-center justify-between border-b pb-3 mb-3">
        <h3 className="font-medium">Your Cart ({itemCount})</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="h-[250px] pr-4">
        <div className="space-y-4">
          {items.map((item) => {
            const inventoryCount = getInventoryCount(item.id)
            return (
              <div key={item.id} className="flex items-center gap-3">
                <div className="w-12 h-12 bg-muted rounded-md flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.title}</p>
                  <div className="flex items-center justify-between mt-1">
                    <div>
                      <p className="text-sm">
                        {item.price} × {item.quantity}
                      </p>
                      {inventoryCount < 10 && (
                        <p className="text-xs text-yellow-600">
                          {inventoryCount === 0 ? "Out of stock" : `Only ${inventoryCount} left`}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </ScrollArea>

      <div className="border-t pt-3 mt-3">
        <div className="flex items-center justify-between mb-4">
          <span className="font-medium">Subtotal</span>
          <span className="font-bold">${subtotal.toFixed(2)}</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Link href="/cart" className="w-full">
            <Button variant="outline" size="sm" className="w-full" onClick={onClose}>
              View Cart
            </Button>
          </Link>
          <Link href="/checkout" className="w-full">
            <Button size="sm" className="w-full" onClick={onClose}>
              Checkout
              <ArrowRight className="ml-2 h-3 w-3" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

