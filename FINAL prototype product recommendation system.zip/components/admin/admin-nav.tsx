"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"

export default function AdminNav() {
  const pathname = usePathname()

  return (
    <div className="bg-card border-b mb-6">
      <div className="container mx-auto px-4">
        <div className="flex overflow-x-auto py-2 gap-2">
          <Link href="/">
            <Button variant="outline" size="sm" className="whitespace-nowrap">
              <Home className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

