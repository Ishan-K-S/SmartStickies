"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useProducts } from "@/contexts/product-context"
import { useInventory } from "@/contexts/inventory-context"
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react"
import SampleCSVGenerator from "@/components/admin/sample-csv-generator"

export default function InventoryUploadSimple() {
  const { addProduct } = useProducts()
  const { updateInventory } = useInventory()
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [processingStep, setProcessingStep] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [importedCount, setImportedCount] = useState(0)

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Only accept CSV files for simplicity
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setUploadError("Please upload a CSV file")
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setUploadError(null)
    setUploadSuccess(false)
    setProcessingStep("Reading file...")

    // Simulate progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + 10
      })
    }, 300)

    // Read the file
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        setProcessingStep("Parsing data...")
        const csvData = event.target?.result as string
        const lines = csvData.split("\n")
        const headers = lines[0].split(",").map((h) => h.trim().toLowerCase())

        // Process each line
        const products = lines
          .slice(1)
          .filter((line) => line.trim())
          .map((line) => {
            const values = line.split(",").map((v) => v.trim())
            const product: any = {}

            headers.forEach((header, index) => {
              if (values[index]) {
                switch (header) {
                  case "title":
                  case "name":
                  case "product":
                  case "product name":
                    product.title = values[index]
                    break
                  case "description":
                    product.description = values[index]
                    break
                  case "price":
                    product.price = values[index]
                    break
                  case "category":
                    product.category = values[index]
                    break
                  case "inventory":
                  case "stock":
                  case "quantity":
                    product.inventory = Number.parseInt(values[index], 10)
                    break
                }
              }
            })

            return product
          })
          .filter((product) => product.title) // Only keep products with a title

        // Import the products
        setProcessingStep("Importing products...")
        let importCount = 0

        products.forEach((product, index) => {
          // Generate a unique ID
          const categoryPrefix = (product.category || "product").toLowerCase().replace(/\s+/g, "-")
          const timestamp = Date.now().toString().slice(-6) + index
          const newId = `${categoryPrefix}-${timestamp}`

          // Format price
          const formattedPrice =
            typeof product.price === "string" && !product.price.startsWith("$")
              ? `$${product.price}`
              : product.price || "$0.00"

          // Create product object
          const newProduct = {
            id: newId,
            title: product.title,
            description: product.description || `Description for ${product.title}`,
            price: formattedPrice,
            category: product.category || "Hard Goods",
          }

          // Add to products context
          addProduct(newProduct)

          // Update inventory
          if (product.inventory !== undefined) {
            updateInventory(newId, product.inventory)
          } else {
            updateInventory(newId, 10) // Default inventory
          }

          importCount++
        })

        setImportedCount(importCount)
        setUploadProgress(100)
        setUploadSuccess(true)
        setProcessingStep("Import complete!")
      } catch (error) {
        console.error("Error parsing file:", error)
        setUploadError("Failed to parse the file. Please ensure it's a valid CSV file.")
      } finally {
        clearInterval(progressInterval)
        setIsUploading(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }
    }

    reader.onerror = () => {
      clearInterval(progressInterval)
      setUploadError("Error reading the file. Please try again.")
      setIsUploading(false)
      setProcessingStep(null)
    }

    reader.readAsText(file)
  }

  // Reset the upload process
  const handleReset = () => {
    setUploadSuccess(false)
    setUploadError(null)
    setImportedCount(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Bulk Inventory Upload
        </CardTitle>
        <CardDescription>
          Upload product inventory in bulk using CSV files. The system will automatically import your products.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <Alert>
          <FileSpreadsheet className="h-4 w-4" />
          <AlertTitle>CSV Format</AlertTitle>
          <AlertDescription>
            Upload inventory data in CSV format with headers. Required fields: Title, Description, Price, Category,
            Inventory.
          </AlertDescription>
        </Alert>

        <div className="grid gap-4">
          <Label htmlFor="inventory-file">Select CSV File</Label>
          <Input
            id="inventory-file"
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            disabled={isUploading}
            ref={fileInputRef}
          />

          <div className="flex justify-end gap-2">
            <SampleCSVGenerator />
          </div>

          {isUploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{processingStep || "Uploading..."}</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          {uploadError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{uploadError}</AlertDescription>
            </Alert>
          )}

          {uploadSuccess && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-600">Success</AlertTitle>
              <AlertDescription className="text-green-600">
                Successfully imported {importedCount} products from your CSV file.
              </AlertDescription>
              <Button className="mt-4 bg-green-600 hover:bg-green-700 text-white" onClick={handleReset}>
                Upload Another File
              </Button>
            </Alert>
          )}
        </div>

        <div className="bg-muted p-4 rounded-md">
          <h3 className="font-medium mb-2">CSV Format Instructions</h3>
          <p className="text-sm mb-2">Your CSV file should include the following headers:</p>
          <ul className="text-sm list-disc pl-5 space-y-1">
            <li>Title or Name (required)</li>
            <li>Description</li>
            <li>Price</li>
            <li>Category</li>
            <li>Inventory or Stock</li>
          </ul>
          <p className="text-sm mt-2">Download a sample CSV file using the button above to see the correct format.</p>
        </div>
      </CardContent>
    </Card>
  )
}

