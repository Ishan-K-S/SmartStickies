"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useProducts } from "@/contexts/product-context"
import { useInventory } from "@/contexts/inventory-context"
import {
  Upload,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle,
  X,
  Edit,
  Save,
  Plus,
  Minus,
  FileText,
  FileType,
} from "lucide-react"
import type { Product } from "@/lib/types"
import SampleCSVGenerator from "@/components/admin/sample-csv-generator"
import SampleExcelGenerator from "@/components/admin/sample-excel-generator"
import SampleJsonGenerator from "@/components/admin/sample-json-generator"
import { generateProductDescription } from "@/lib/product-description-generator"
import Link from "next/link"
import DetailedProductImage from "@/components/detailed-product-image"

// Add a try-catch block to handle XLSX import
let XLSX: any
try {
  XLSX = require("xlsx")
} catch (error) {
  console.error("XLSX library not available:", error)
  // Provide a fallback implementation
  XLSX = {
    read: () => ({ SheetNames: ["Sheet1"], Sheets: { Sheet1: {} } }),
    utils: {
      sheet_to_json: () => [],
      book_new: () => ({}),
      aoa_to_sheet: () => ({}),
      book_append_sheet: () => {},
    },
    writeFile: () => {},
  }
}

// Define the structure for uploaded product data
interface UploadedProduct {
  id?: string
  title: string
  description?: string
  price?: string | number
  category?: string
  inventory?: number
  status: "complete" | "incomplete" | "processing"
  errors?: string[]
}

export default function InventoryUpload() {
  const { products, addProduct } = useProducts()
  const { updateInventory, getInventoryCount } = useInventory()
  const [uploadedData, setUploadedData] = useState<UploadedProduct[]>([])
  const [activeTab, setActiveTab] = useState("upload")
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [editingProduct, setEditingProduct] = useState<UploadedProduct | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [processingStep, setProcessingStep] = useState<string | null>(null)
  const [importedIds, setImportedIds] = useState<string[]>([])
  const [fileFormat, setFileFormat] = useState<string>("csv")

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    setUploadProgress(0)
    setUploadError(null)
    setUploadSuccess(false)
    setProcessingStep("Reading file...")

    // Detect file format
    const fileExtension = file.name.split(".").pop()?.toLowerCase() || ""
    let detectedFormat = "unknown"

    if (fileExtension === "csv") {
      detectedFormat = "csv"
    } else if (["xlsx", "xls"].includes(fileExtension)) {
      detectedFormat = "excel"
    } else if (["docx", "doc"].includes(fileExtension)) {
      detectedFormat = "word"
    } else if (fileExtension === "txt") {
      detectedFormat = "txt"
    } else if (fileExtension === "json") {
      detectedFormat = "json"
    }

    setFileFormat(detectedFormat)

    // Simulate progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + 10
      })
    }, 300)

    // Parse the file based on format
    if (detectedFormat === "csv" || detectedFormat === "txt") {
      parseTextFile(file, progressInterval)
    } else if (detectedFormat === "excel") {
      parseExcelFile(file, progressInterval)
    } else if (detectedFormat === "word") {
      parseWordFile(file, progressInterval)
    } else if (detectedFormat === "json") {
      parseJsonFile(file, progressInterval)
    } else {
      clearInterval(progressInterval)
      setUploadError("Unsupported file format. Please upload a CSV, Excel, Word, or JSON file.")
      setIsUploading(false)
      setProcessingStep(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  // Parse text file (CSV, TXT)
  const parseTextFile = (file: File, progressInterval: NodeJS.Timeout) => {
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        setProcessingStep("Parsing data...")
        const csvData = event.target?.result as string
        const parsedData = parseCSV(csvData)

        setProcessingStep("Validating products...")
        const validatedProducts = validateProducts(parsedData)

        setUploadedData(validatedProducts)
        setUploadProgress(100)

        // If there are incomplete products, switch to the review tab
        if (validatedProducts.some((p) => p.status === "incomplete")) {
          setActiveTab("review")
        } else {
          setActiveTab("confirm")
        }

        setProcessingStep(null)
        setUploadSuccess(true)
      } catch (error) {
        console.error("Error parsing file:", error)
        setUploadError("Failed to parse the file. Please ensure it's a valid CSV file.")
      } finally {
        clearInterval(progressInterval)
        setIsUploading(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }
    }

    reader.onerror = () => {
      clearInterval(progressInterval)
      setUploadError("Error reading the file. Please try again.")
      setIsUploading(false)
      setProcessingStep(null)
    }

    reader.readAsText(file)
  }

  // Parse Excel file
  const parseExcelFile = (file: File, progressInterval: NodeJS.Timeout) => {
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        setProcessingStep("Parsing Excel data...")
        const data = event.target?.result

        // Add error handling for XLSX
        if (!XLSX || typeof XLSX.read !== "function") {
          throw new Error("XLSX library not properly loaded")
        }

        const workbook = XLSX.read(data, { type: "array" })

        // Check if workbook is valid
        if (!workbook || !workbook.SheetNames || workbook.SheetNames.length === 0) {
          throw new Error("Invalid Excel file format")
        }

        // Get the first worksheet
        const worksheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[worksheetName]

        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 })

        // Process the data
        if (jsonData.length < 2) {
          throw new Error("Excel file must contain headers and at least one data row")
        }

        const headers = (jsonData[0] as string[]).map((h) => h.toLowerCase())
        const rows = jsonData.slice(1) as string[][]

        const parsedData: UploadedProduct[] = rows.map((row) => {
          const product: UploadedProduct = {
            title: "",
            status: "incomplete",
            errors: [],
          }

          headers.forEach((header, index) => {
            if (row[index]) {
              switch (header) {
                case "title":
                case "name":
                case "product":
                case "product name":
                  product.title = row[index]
                  break
                case "description":
                  product.description = row[index]
                  break
                case "price":
                  product.price = row[index]
                  break
                case "category":
                  product.category = row[index]
                  break
                case "inventory":
                case "stock":
                case "quantity":
                  product.inventory = Number.parseInt(row[index], 10)
                  break
              }
            }
          })

          return product
        })

        setProcessingStep("Validating products...")
        const validatedProducts = validateProducts(parsedData)

        setUploadedData(validatedProducts)
        setUploadProgress(100)

        // If there are incomplete products, switch to the review tab
        if (validatedProducts.some((p) => p.status === "incomplete")) {
          setActiveTab("review")
        } else {
          setActiveTab("confirm")
        }

        setProcessingStep(null)
        setUploadSuccess(true)
      } catch (error) {
        console.error("Error parsing Excel file:", error)
        setUploadError("Failed to parse the Excel file. Please ensure it has the correct format.")
      } finally {
        clearInterval(progressInterval)
        setIsUploading(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }
    }

    reader.onerror = () => {
      clearInterval(progressInterval)
      setUploadError("Error reading the Excel file. Please try again.")
      setIsUploading(false)
      setProcessingStep(null)
    }

    reader.readAsArrayBuffer(file)
  }

  // Parse Word file
  const parseWordFile = (file: File, progressInterval: NodeJS.Timeout) => {
    // For Word files, we'll extract text and try to parse tables
    // This is a simplified implementation
    setProcessingStep("Extracting data from Word document...")

    // In a real implementation, you would use a library like mammoth.js
    // For this demo, we'll simulate parsing
    setTimeout(() => {
      try {
        // Simulate extracted data
        const mockData: UploadedProduct[] = [
          {
            title: "Product from Word Doc 1",
            description: "This is a product extracted from a Word document",
            price: "29.99",
            category: "Hard Goods",
            inventory: 10,
            status: "complete",
            errors: [],
          },
          {
            title: "Product from Word Doc 2",
            description: "Another product from the Word document",
            price: "19.99",
            category: "Cleaning products",
            inventory: 5,
            status: "complete",
            errors: [],
          },
        ]

        setUploadedData(mockData)
        setUploadProgress(100)
        setActiveTab("review")
        setProcessingStep(null)
        setUploadSuccess(true)
      } catch (error) {
        console.error("Error parsing Word file:", error)
        setUploadError("Failed to parse the Word document. Please ensure it contains properly formatted tables.")
      } finally {
        clearInterval(progressInterval)
        setIsUploading(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }
    }, 2000)
  }

  // Parse JSON file
  const parseJsonFile = (file: File, progressInterval: NodeJS.Timeout) => {
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        setProcessingStep("Parsing JSON data...")
        const jsonData = JSON.parse(event.target?.result as string)

        // Handle array of products
        let parsedData: UploadedProduct[] = []

        if (Array.isArray(jsonData)) {
          parsedData = jsonData.map((item) => ({
            title: item.title || item.name || "",
            description: item.description || "",
            price: item.price || "",
            category: item.category || "",
            inventory: item.inventory || item.stock || item.quantity || undefined,
            status: "incomplete",
            errors: [],
          }))
        } else {
          // Handle single product or other formats
          setUploadError("JSON file must contain an array of products")
          clearInterval(progressInterval)
          setIsUploading(false)
          return
        }

        setProcessingStep("Validating products...")
        const validatedProducts = validateProducts(parsedData)

        setUploadedData(validatedProducts)
        setUploadProgress(100)

        // If there are incomplete products, switch to the review tab
        if (validatedProducts.some((p) => p.status === "incomplete")) {
          setActiveTab("review")
        } else {
          setActiveTab("confirm")
        }

        setProcessingStep(null)
        setUploadSuccess(true)
      } catch (error) {
        console.error("Error parsing JSON file:", error)
        setUploadError("Failed to parse the JSON file. Please ensure it's valid JSON.")
      } finally {
        clearInterval(progressInterval)
        setIsUploading(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }
    }

    reader.onerror = () => {
      clearInterval(progressInterval)
      setUploadError("Error reading the JSON file. Please try again.")
      setIsUploading(false)
      setProcessingStep(null)
    }

    reader.readAsText(file)
  }

  // Parse CSV data
  const parseCSV = (csvData: string): UploadedProduct[] => {
    const lines = csvData.split("\n")
    const headers = lines[0].split(",").map((h) => h.trim().toLowerCase())

    return lines
      .slice(1)
      .filter((line) => line.trim())
      .map((line) => {
        const values = line.split(",").map((v) => v.trim())
        const product: UploadedProduct = {
          title: "",
          status: "incomplete",
          errors: [],
        }

        headers.forEach((header, index) => {
          if (values[index]) {
            switch (header) {
              case "title":
              case "name":
              case "product":
              case "product name":
                product.title = values[index]
                break
              case "description":
                product.description = values[index]
                break
              case "price":
                product.price = values[index]
                break
              case "category":
                product.category = values[index]
                break
              case "inventory":
              case "stock":
              case "quantity":
                product.inventory = Number.parseInt(values[index], 10)
                break
            }
          }
        })

        return product
      })
  }

  // Validate products and mark incomplete ones
  const validateProducts = (products: UploadedProduct[]): UploadedProduct[] => {
    return products.map((product) => {
      const errors: string[] = []

      if (!product.title) {
        errors.push("Title is required")
      }

      if (!product.description) {
        errors.push("Description is missing")
      }

      if (!product.price) {
        errors.push("Price is missing")
      }

      if (!product.category) {
        errors.push("Category is missing")
      }

      if (product.inventory === undefined) {
        errors.push("Inventory count is missing")
      }

      return {
        ...product,
        status: errors.length > 0 ? "incomplete" : "complete",
        errors,
      }
    })
  }

  // Handle editing a product
  const handleEditProduct = (product: UploadedProduct) => {
    setEditingProduct(product)
  }

  // Handle saving edited product
  const handleSaveEdit = () => {
    if (!editingProduct) return

    const updatedData = uploadedData.map((product) => {
      if (product.title === editingProduct.title) {
        const errors: string[] = []

        if (!editingProduct.title) errors.push("Title is required")
        if (!editingProduct.description) errors.push("Description is missing")
        if (!editingProduct.price) errors.push("Price is missing")
        if (!editingProduct.category) errors.push("Category is missing")
        if (editingProduct.inventory === undefined) errors.push("Inventory count is missing")

        return {
          ...editingProduct,
          status: errors.length > 0 ? "incomplete" : "complete",
          errors,
        }
      }
      return product
    })

    setUploadedData(updatedData)
    setEditingProduct(null)
  }

  // Handle canceling edit
  const handleCancelEdit = () => {
    setEditingProduct(null)
  }

  // Handle importing products
  const handleImportProducts = () => {
    setIsUploading(true)
    setProcessingStep("Importing products...")
    setUploadProgress(0)

    // Simulate progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + 5
      })
    }, 100)

    // Process each product
    setTimeout(() => {
      uploadedData.forEach((uploadedProduct, index) => {
        // Generate a unique ID
        const categoryPrefix = (uploadedProduct.category || "product").toLowerCase().replace(/\s+/g, "-")
        const timestamp = Date.now().toString().slice(-6) + index
        const newId = `${categoryPrefix}-${timestamp}`

        // Format price
        const formattedPrice =
          typeof uploadedProduct.price === "string" && !uploadedProduct.price.startsWith("$")
            ? `$${uploadedProduct.price}`
            : uploadedProduct.price

        // Create product object
        const product: Product = {
          id: newId,
          title: uploadedProduct.title,
          description:
            uploadedProduct.description ||
            generateProductDescription(uploadedProduct.title, uploadedProduct.category || "Hard Goods"),
          price: formattedPrice || "$0.00",
          category: uploadedProduct.category || "Hard Goods",
        }

        // Add to products context
        addProduct(product)

        // Update inventory
        if (uploadedProduct.inventory !== undefined) {
          updateInventory(newId, uploadedProduct.inventory)
        } else {
          updateInventory(newId, 10) // Default inventory
        }
      })

      clearInterval(progressInterval)
      setUploadProgress(100)
      setProcessingStep("Import complete!")

      // Store the imported product IDs and reset state
      const importedProductIds = uploadedData.map((_, index) => {
        const categoryPrefix = (uploadedData[index].category || "product").toLowerCase().replace(/\s+/g, "-")
        const timestamp = Date.now().toString().slice(-6) + index
        return `${categoryPrefix}-${timestamp}`
      })

      setTimeout(() => {
        setUploadedData([])
        setIsUploading(false)
        setProcessingStep(null)
        setActiveTab("success") // New tab for success view
        setImportedIds(importedProductIds) // Store the IDs
        setUploadSuccess(true)
      }, 1500)
    }, 1500)
  }

  // Handle adjusting inventory
  const handleAdjustInventory = (index: number, amount: number) => {
    const updatedData = [...uploadedData]
    const currentInventory = updatedData[index].inventory || 0
    updatedData[index].inventory = Math.max(0, currentInventory + amount)
    setUploadedData(updatedData)
  }

  // Handle input change for editing product
  const handleEditInputChange = (field: keyof UploadedProduct, value: string | number) => {
    if (!editingProduct) return

    setEditingProduct({
      ...editingProduct,
      [field]: value,
    })
  }

  // Handle category change
  const handleCategoryChange = (value: string) => {
    if (!editingProduct) return

    setEditingProduct({
      ...editingProduct,
      category: value,
    })
  }

  // Reset the upload process
  const handleReset = () => {
    setUploadedData([])
    setActiveTab("upload")
    setUploadSuccess(false)
    setUploadError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // Get file format icon
  const getFileFormatIcon = () => {
    switch (fileFormat) {
      case "csv":
        return <FileSpreadsheet className="h-4 w-4" />
      case "excel":
        return <FileSpreadsheet className="h-4 w-4 text-green-600" />
      case "word":
        return <FileText className="h-4 w-4 text-blue-600" />
      case "json":
        return <FileType className="h-4 w-4 text-yellow-600" />
      default:
        return <FileType className="h-4 w-4" />
    }
  }

  // Get file format name
  const getFileFormatName = () => {
    switch (fileFormat) {
      case "csv":
        return "CSV"
      case "excel":
        return "Excel"
      case "word":
        return "Word Document"
      case "json":
        return "JSON"
      default:
        return "Unknown Format"
    }
  }

  // Count complete and incomplete products
  const completeCount = uploadedData.filter((p) => p.status === "complete").length
  const incompleteCount = uploadedData.filter((p) => p.status === "incomplete").length

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Bulk Inventory Upload
        </CardTitle>
        <CardDescription>
          Upload product inventory in bulk using CSV, Excel, Word, or JSON files. The system will help you fill in any
          missing information.
        </CardDescription>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upload" disabled={isUploading}>
              Upload File
            </TabsTrigger>
            <TabsTrigger value="review" disabled={uploadedData.length === 0 || isUploading}>
              Review Data
            </TabsTrigger>
            <TabsTrigger value="confirm" disabled={uploadedData.length === 0 || incompleteCount > 0 || isUploading}>
              Confirm Import
            </TabsTrigger>
            <TabsTrigger value="success" disabled={importedIds.length === 0}>
              Live Products
            </TabsTrigger>
          </TabsList>

          {/* Upload Tab */}
          <TabsContent value="upload" className="mt-4 space-y-4">
            <Alert>
              {getFileFormatIcon()}
              <AlertTitle>Supported Formats</AlertTitle>
              <AlertDescription>
                Upload inventory data in CSV, Excel (.xlsx, .xls), Word (.docx, .doc), or JSON format. The system will
                automatically detect and parse the file format.
              </AlertDescription>
            </Alert>

            <div className="grid gap-4">
              <Label htmlFor="inventory-file">Select File</Label>
              <Input
                id="inventory-file"
                type="file"
                accept=".csv,.xlsx,.xls,.docx,.doc,.txt,.json"
                onChange={handleFileUpload}
                disabled={isUploading}
                ref={fileInputRef}
              />

              {/* Add the sample file generator buttons */}
              <div className="flex justify-end gap-2">
                <SampleCSVGenerator />
                <SampleExcelGenerator />
                <SampleJsonGenerator />
              </div>

              {isUploading && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{processingStep || "Uploading..."}</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              )}

              {uploadError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{uploadError}</AlertDescription>
                </Alert>
              )}

              {uploadSuccess && (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-600">Success</AlertTitle>
                  <AlertDescription className="text-green-600">
                    {getFileFormatName()} file processed successfully. Products are ready for review.
                  </AlertDescription>
                </Alert>
              )}
            </div>

            <div className="bg-muted p-4 rounded-md">
              <h3 className="font-medium mb-2">Supported File Formats</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4" />
                  <span className="text-sm">CSV: Comma-separated values with headers</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Excel: .xlsx or .xls spreadsheets</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Word: .docx or .doc files with tables</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileType className="h-4 w-4 text-yellow-600" />
                  <span className="text-sm">JSON: Array of product objects</span>
                </div>
              </div>
              <div className="mt-4">
                <h4 className="text-sm font-medium">Required Fields:</h4>
                <p className="text-xs text-muted-foreground">
                  Title/Name, Description, Price, Category, Inventory/Stock/Quantity
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Review Tab */}
          <TabsContent value="review" className="mt-4 space-y-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-medium">Review Products</h3>
                <p className="text-sm text-muted-foreground">
                  Complete missing information before importing. File format: {getFileFormatName()}
                </p>
              </div>
              <div className="flex gap-2">
                <Badge variant={incompleteCount > 0 ? "destructive" : "outline"}>{incompleteCount} Incomplete</Badge>
                <Badge variant="outline">{completeCount} Complete</Badge>
              </div>
            </div>

            <div className="rounded-md border overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Inventory</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {uploadedData.map((product, index) => (
                      <TableRow key={index} className={product.status === "incomplete" ? "bg-red-50" : ""}>
                        <TableCell className="font-medium">{product.title}</TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {product.description || <span className="text-red-500">Missing</span>}
                        </TableCell>
                        <TableCell>{product.price || <span className="text-red-500">Missing</span>}</TableCell>
                        <TableCell>{product.category || <span className="text-red-500">Missing</span>}</TableCell>
                        <TableCell>
                          {product.inventory !== undefined ? (
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => handleAdjustInventory(index, -1)}
                                disabled={product.inventory <= 0}
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span>{product.inventory}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => handleAdjustInventory(index, 1)}
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                          ) : (
                            <span className="text-red-500">Missing</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={product.status === "complete" ? "default" : "destructive"}>
                            {product.status === "complete" ? "Complete" : "Incomplete"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleEditProduct(product)}>
                            <Edit className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleReset}>
                Cancel
              </Button>
              <Button onClick={() => setActiveTab("confirm")} disabled={incompleteCount > 0}>
                Continue to Import
              </Button>
            </div>
          </TabsContent>

          {/* Confirm Tab */}
          <TabsContent value="confirm" className="mt-4 space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-600">Ready to Import</AlertTitle>
              <AlertDescription className="text-green-600">
                All {uploadedData.length} products from your {getFileFormatName()} file are ready to be imported into
                your inventory.
              </AlertDescription>
            </Alert>

            <div className="rounded-md border overflow-hidden">
              <div className="overflow-x-auto max-h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Inventory</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {uploadedData.map((product, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{product.title}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>{product.price}</TableCell>
                        <TableCell>{product.inventory}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{processingStep || "Processing..."}</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleReset} disabled={isUploading}>
                Cancel
              </Button>
              <Button onClick={handleImportProducts} disabled={isUploading}>
                {isUploading ? "Importing..." : "Import Products"}
              </Button>
            </div>
          </TabsContent>

          {/* Success Tab */}
          <TabsContent value="success" className="mt-4 space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-600">Products Live on Site!</AlertTitle>
              <AlertDescription className="text-green-600">
                Your products from the {getFileFormatName()} file have been successfully imported and are now live on
                the website. Customers can immediately see and purchase these products.
              </AlertDescription>
            </Alert>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {importedIds.map((id, index) => {
                const product = products.find((p) => p.id === id)
                if (!product) return null

                return (
                  <Card key={id} className="overflow-hidden">
                    <div className="h-40 bg-muted">
                      <DetailedProductImage product={product} className="h-full w-full" />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-medium truncate">{product.title}</h3>
                      <p className="text-sm text-muted-foreground">{product.category}</p>
                      <div className="flex justify-between items-center mt-2">
                        <span className="font-bold">{product.price}</span>
                        <Badge variant="outline">{getInventoryCount(product.id)} in stock</Badge>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={handleReset}>
                Upload More Products
              </Button>
              <Link href="/" passHref>
                <Button>View Products on Site</Button>
              </Link>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Edit Product</h3>
              <Button variant="ghost" size="icon" onClick={handleCancelEdit}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-title">Title</Label>
                <Input
                  id="edit-title"
                  value={editingProduct.title}
                  onChange={(e) => handleEditInputChange("title", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={editingProduct.description || ""}
                  onChange={(e) => handleEditInputChange("description", e.target.value)}
                  placeholder="Enter product description"
                />
              </div>

              <div>
                <Label htmlFor="edit-price">Price</Label>
                <Input
                  id="edit-price"
                  value={editingProduct.price || ""}
                  onChange={(e) => handleEditInputChange("price", e.target.value)}
                  placeholder="29.99"
                />
              </div>

              <div>
                <Label htmlFor="edit-category">Category</Label>
                <Select value={editingProduct.category || ""} onValueChange={handleCategoryChange}>
                  <SelectTrigger id="edit-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Hard Goods">Hard Goods</SelectItem>
                    <SelectItem value="Cleaning products">Cleaning products</SelectItem>
                    <SelectItem value="Syrups">Syrups</SelectItem>
                    <SelectItem value="Services">Services</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="edit-inventory">Inventory</Label>
                <Input
                  id="edit-inventory"
                  type="number"
                  min="0"
                  value={editingProduct.inventory || 0}
                  onChange={(e) => handleEditInputChange("inventory", Number.parseInt(e.target.value, 10))}
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={handleCancelEdit}>
                  Cancel
                </Button>
                <Button onClick={handleSaveEdit}>
                  <Save className="h-4 w-4 mr-1" />
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}

