"use client"

import { Button } from "@/components/ui/button"
import { FileSpreadsheet } from "lucide-react"
import { useState } from "react"

export default function SampleExcelGenerator() {
  const [isGenerating, setIsGenerating] = useState(false)

  const generateSampleExcel = () => {
    setIsGenerating(true)

    // Create sample data as CSV instead of relying on XLSX
    const csvData = [
      "Title,Description,Price,Category,Inventory",
      "Premium Coffee Blend,Rich aromatic coffee blend,29.99,Hard Goods,15",
      "Cleaning Solution,Effective cleaning for coffee machines,19.50,Cleaning products,8",
      "Vanilla Syrup,Natural vanilla flavor for coffee,12.99,Syrups,20",
      "Coffee Grinder,Professional grade coffee grinder,89.99,Hard Goods,5",
      "Espresso Cups Set,Set of 4 porcelain espresso cups,24.99,Hard Goods,12",
    ].join("\n")

    // Create a blob and download
    const blob = new Blob([csvData], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "sample-inventory.csv"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    setIsGenerating(false)
  }

  return (
    <Button variant="outline" size="sm" onClick={generateSampleExcel} disabled={isGenerating}>
      <FileSpreadsheet className="h-4 w-4 mr-1" />
      {isGenerating ? "Generating..." : "Sample Excel"}
    </Button>
  )
}

