"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Lock, Unlock, Download, FileSpreadsheet, Eye, EyeOff } from "lucide-react"
// Add the useProducts import
import { useProducts } from "@/contexts/product-context"

// The correct access code (only known to the owner)
const OWNER_ACCESS_CODE = "1234567890"

// Function to generate a unique product code
function generateProductCode(product: any, index: number): string {
  // Create a code based on category and index
  const categoryPrefix: Record<string, string> = {
    "Hard Goods": "10",
    "Cleaning products": "20",
    Syrups: "30",
    Services: "40",
  }

  const prefix = categoryPrefix[product.category] || "00"
  const sequentialNumber = String(index + 1).padStart(3, "0")

  // Combine to create a 5-digit code
  return `${prefix}${sequentialNumber}`
}

// Function to create a universal link for a product
function createUniversalLink(productCode: string): string {
  return `https://guerillacoffee.com/product?code=${productCode}`
}

// Update the ProductDataPanel component to use the products context
export default function ProductDataPanel() {
  const { products } = useProducts()
  const [accessCode, setAccessCode] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showAccessCode, setShowAccessCode] = useState(false)
  const [copiedState, setCopiedState] = useState<Record<string, boolean>>({})
  const [activeTab, setActiveTab] = useState("table")
  const csvRef = useRef<HTMLTextAreaElement>(null)
  const tsvRef = useRef<HTMLTextAreaElement>(null)

  // Generate product data from the context
  const productData = products.map((product, index) => {
    const productCode = generateProductCode(product, index)
    const universalLink = createUniversalLink(productCode)

    return {
      name: product.title,
      code: productCode,
      link: universalLink,
      category: product.category,
      price: product.price,
    }
  })

  // Format data for export
  const csvData = [
    ["Name", "Associated Code", "Associated Link", "Category", "Price"],
    ...productData.map((item) => [item.name, item.code, item.link, item.category, item.price]),
  ]
    .map((row) => row.map((cell) => `"${cell}"`).join(","))
    .join("\n")

  const tsvData = [
    ["Name", "Associated Code", "Associated Link", "Category", "Price"],
    ...productData.map((item) => [item.name, item.code, item.link, item.category, item.price]),
  ]
    .map((row) => row.join("\t"))
    .join("\n")

  // Handle authentication
  const handleAuthenticate = () => {
    if (accessCode === OWNER_ACCESS_CODE) {
      setIsAuthenticated(true)
    } else {
      alert("Invalid access code. Please try again.")
    }
  }

  // Handle copy to clipboard
  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedState({ ...copiedState, [key]: true })
      setTimeout(() => {
        setCopiedState({ ...copiedState, [key]: false })
      }, 2000)
    })
  }

  // Download data as CSV
  const downloadCSV = () => {
    const blob = new Blob([csvData], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", "guerilla_coffee_products.csv")
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Select all text in textarea
  const selectAllText = (ref: React.RefObject<HTMLTextAreaElement>) => {
    if (ref.current) {
      ref.current.select()
    }
  }

  if (!isAuthenticated) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Owner Access Required
          </CardTitle>
          <CardDescription>Please enter your 10-digit owner access code to view product data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <div className="relative w-full">
              <Input
                type={showAccessCode ? "text" : "password"}
                placeholder="Enter access code"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowAccessCode(!showAccessCode)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                {showAccessCode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <Button onClick={handleAuthenticate}>Access</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Unlock className="h-5 w-5" />
            Product Data Management
          </CardTitle>
          <CardDescription>Manage and export your product codes and universal links</CardDescription>
        </div>
        <Badge variant="outline" className="ml-auto">
          Owner Access
        </Badge>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="table">Table View</TabsTrigger>
            <TabsTrigger value="csv">CSV Export</TabsTrigger>
            <TabsTrigger value="tsv">TSV Export</TabsTrigger>
          </TabsList>

          <TabsContent value="table" className="mt-4">
            <div className="rounded-md border overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[300px]">Product Name</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {productData.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.code}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.price}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(item.link, `link-${index}`)}
                          >
                            {copiedState[`link-${index}`] ? (
                              <Check className="h-4 w-4 mr-1" />
                            ) : (
                              <Copy className="h-4 w-4 mr-1" />
                            )}
                            {copiedState[`link-${index}`] ? "Copied" : "Copy Link"}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="csv" className="mt-4 space-y-4">
            <Alert>
              <FileSpreadsheet className="h-4 w-4" />
              <AlertTitle>CSV Format</AlertTitle>
              <AlertDescription>This data is formatted for Excel and other spreadsheet applications.</AlertDescription>
            </Alert>

            <div className="grid gap-4">
              <textarea
                ref={csvRef}
                className="min-h-[300px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={csvData}
                readOnly
                onClick={() => selectAllText(csvRef)}
              />

              <div className="flex gap-2">
                <Button onClick={() => copyToClipboard(csvData, "csv")} className="flex-1">
                  {copiedState["csv"] ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                  {copiedState["csv"] ? "Copied to Clipboard" : "Copy to Clipboard"}
                </Button>

                <Button variant="outline" onClick={downloadCSV}>
                  <Download className="h-4 w-4 mr-2" />
                  Download CSV
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tsv" className="mt-4 space-y-4">
            <Alert>
              <FileSpreadsheet className="h-4 w-4" />
              <AlertTitle>TSV Format (Tab-Separated)</AlertTitle>
              <AlertDescription>This format is ideal for pasting directly into Google Sheets.</AlertDescription>
            </Alert>

            <div className="grid gap-4">
              <textarea
                ref={tsvRef}
                className="min-h-[300px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={tsvData}
                readOnly
                onClick={() => selectAllText(tsvRef)}
              />

              <Button onClick={() => copyToClipboard(tsvData, "tsv")}>
                {copiedState["tsv"] ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                {copiedState["tsv"] ? "Copied to Clipboard" : "Copy to Clipboard"}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => setIsAuthenticated(false)}>
          <Lock className="h-4 w-4 mr-2" />
          Lock Panel
        </Button>

        <div className="text-sm text-muted-foreground">
          {productData.length} products • Last updated: {new Date().toLocaleDateString()}
        </div>
      </CardFooter>
    </Card>
  )
}

