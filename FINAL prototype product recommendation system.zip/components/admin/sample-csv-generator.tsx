"use client"

import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function SampleCSVGenerator() {
  const handleDownloadSample = () => {
    // Create sample CSV content
    const csvContent = `Title,Description,Price,Category,Inventory
Premium Coffee Blend,Rich aromatic coffee blend with notes of chocolate and caramel,29.99,Hard Goods,15
Cleaning Solution,Effective cleaning solution for coffee machines,19.50,Cleaning products,8
Vanilla Syrup,Natural vanilla flavor for coffee drinks,12.99,Syrups,20
Barista Training,Professional barista training session (2 hours),150.00,Services,5
Espresso Machine Maintenance,Regular maintenance service for espresso machines,75.00,Services,10
Organic Dark Roast,Certified organic dark roast coffee beans,34.99,Hard Goods,12
Caramel Syrup,Rich caramel flavor for coffee and desserts,12.99,Syrups,18
Descaling Powder,Removes mineral buildup in coffee machines,15.99,Cleaning products,25`

    // Create a blob and download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.setAttribute("download", "sample_inventory.csv")
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <Button variant="outline" onClick={handleDownloadSample}>
      <Download className="mr-2 h-4 w-4" />
      Download Sample CSV
    </Button>
  )
}

