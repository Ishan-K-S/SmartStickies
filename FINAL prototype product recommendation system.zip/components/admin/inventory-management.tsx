"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus, Minus, Save, Package, Search, PlusCircle } from "lucide-react"
import { coffeeProducts } from "@/lib/product-data"
import { useInventory } from "@/contexts/inventory-context"
import DetailedProductImage from "@/components/detailed-product-image"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

// Add the useProducts import
import { useProducts } from "@/contexts/product-context"

export default function InventoryManagement() {
  const { products } = useProducts()
  const { inventory, updateInventory, incrementInventory } = useInventory()
  const [searchQuery, setSearchQuery] = useState("")
  const [editingInventory, setEditingInventory] = useState<Record<string, number>>({})
  const [newProduct, setNewProduct] = useState({
    title: "",
    description: "",
    price: "",
    category: "Hard Goods",
    initialStock: "10",
  })

  // Filter products based on search query
  const filteredProducts = products.filter(
    (product) =>
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Get inventory count for a product
  const getInventoryCount = (productId: string) => {
    const item = inventory.find((item) => item.productId === productId)
    return item ? item.count : 0
  }

  // Handle inventory change
  const handleInventoryChange = (productId: string, value: string) => {
    const numValue = Number.parseInt(value)
    if (!isNaN(numValue) && numValue >= 0) {
      setEditingInventory({
        ...editingInventory,
        [productId]: numValue,
      })
    }
  }

  // Save inventory changes
  const saveInventoryChanges = (productId: string) => {
    if (editingInventory[productId] !== undefined) {
      updateInventory(productId, editingInventory[productId])

      // Clear the editing state for this product
      const newEditingInventory = { ...editingInventory }
      delete newEditingInventory[productId]
      setEditingInventory(newEditingInventory)
    }
  }

  // Handle increment/decrement inventory
  const handleAdjustInventory = (productId: string, amount: number) => {
    const currentCount = getInventoryCount(productId)
    const newCount = Math.max(0, currentCount + amount)
    updateInventory(productId, newCount)
  }

  // Handle new product input change
  const handleNewProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewProduct({
      ...newProduct,
      [name]: value,
    })
  }

  // Handle category selection
  const handleCategoryChange = (value: string) => {
    setNewProduct({
      ...newProduct,
      category: value,
    })
  }

  // Add new product
  const handleAddProduct = () => {
    // Generate a new product ID
    const categoryPrefix = newProduct.category.toLowerCase().replace(/\s+/g, "-")
    const existingProducts = coffeeProducts.filter((p) => p.id.startsWith(categoryPrefix)).length

    const newProductId = `${categoryPrefix}-${existingProducts + 1}`

    // Create the new product
    const product = {
      id: newProductId,
      title: newProduct.title,
      description: newProduct.description,
      price: newProduct.price.startsWith("$") ? newProduct.price : `$${newProduct.price}`,
      category: newProduct.category,
    }

    // Add to inventory
    const initialStock = Number.parseInt(newProduct.initialStock)
    if (!isNaN(initialStock) && initialStock >= 0) {
      updateInventory(newProductId, initialStock)
    }

    // In a real app, you would save the new product to your database
    // For this demo, we'll just log it
    console.log("New product added:", product)

    // Reset the form
    setNewProduct({
      title: "",
      description: "",
      price: "",
      category: "Hard Goods",
      initialStock: "10",
    })

    // Close the dialog
    document.getElementById("close-dialog")?.click()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search products..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add New Product
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Product</DialogTitle>
              <DialogDescription>
                Enter the details for the new product. It will be added to your inventory.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Product Name</Label>
                <Input
                  id="title"
                  name="title"
                  placeholder="Premium Coffee Blend"
                  value={newProduct.title}
                  onChange={handleNewProductChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="A rich, aromatic blend of premium coffee beans..."
                  value={newProduct.description}
                  onChange={handleNewProductChange}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Price</Label>
                  <Input
                    id="price"
                    name="price"
                    placeholder="29.99"
                    value={newProduct.price}
                    onChange={handleNewProductChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={newProduct.category} onValueChange={handleCategoryChange}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Hard Goods">Hard Goods</SelectItem>
                      <SelectItem value="Cleaning products">Cleaning products</SelectItem>
                      <SelectItem value="Syrups">Syrups</SelectItem>
                      <SelectItem value="Services">Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="initialStock">Initial Stock</Label>
                <Input
                  id="initialStock"
                  name="initialStock"
                  type="number"
                  min="0"
                  placeholder="10"
                  value={newProduct.initialStock}
                  onChange={handleNewProductChange}
                />
              </div>
            </div>

            <DialogFooter>
              <Button id="close-dialog" variant="outline" type="button">
                Cancel
              </Button>
              <Button onClick={handleAddProduct}>Add Product</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Inventory Management
          </CardTitle>
          <CardDescription>Manage your product inventory, update stock levels, and add new products.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">Image</TableHead>
                    <TableHead className="w-[300px]">Product</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>In Stock</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => {
                    const currentStock = getInventoryCount(product.id)
                    const isEditing = editingInventory[product.id] !== undefined
                    const editValue = isEditing ? editingInventory[product.id] : currentStock

                    return (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="w-10 h-10 rounded overflow-hidden">
                            <DetailedProductImage product={product} className="w-full h-full" />
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">
                          <div>{product.title}</div>
                          <div className="text-xs text-muted-foreground">ID: {product.id}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{product.category}</Badge>
                        </TableCell>
                        <TableCell>{product.price}</TableCell>
                        <TableCell>
                          {isEditing ? (
                            <Input
                              type="number"
                              min="0"
                              className="w-20"
                              value={editValue}
                              onChange={(e) => handleInventoryChange(product.id, e.target.value)}
                            />
                          ) : (
                            <Badge
                              variant={currentStock > 0 ? "default" : "destructive"}
                              className="cursor-pointer"
                              onClick={() =>
                                setEditingInventory({
                                  ...editingInventory,
                                  [product.id]: currentStock,
                                })
                              }
                            >
                              {currentStock} in stock
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {isEditing ? (
                              <Button size="sm" onClick={() => saveInventoryChanges(product.id)}>
                                <Save className="h-4 w-4 mr-1" />
                                Save
                              </Button>
                            ) : (
                              <>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => handleAdjustInventory(product.id, -1)}
                                  disabled={currentStock <= 0}
                                >
                                  <Minus className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => handleAdjustInventory(product.id, 1)}
                                >
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">
            {filteredProducts.length} products • {inventory.reduce((sum, item) => sum + item.count, 0)} total items in
            stock
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

