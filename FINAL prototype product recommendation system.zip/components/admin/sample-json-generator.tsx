"use client"

import { Button } from "@/components/ui/button"
import { FileType } from "lucide-react"

export default function SampleJsonGenerator() {
  const generateSampleJson = () => {
    // Create sample data
    const data = [
      {
        title: "Premium Coffee Blend",
        description: "Rich aromatic coffee blend",
        price: "29.99",
        category: "Hard Goods",
        inventory: 15,
      },
      {
        title: "Cleaning Solution",
        description: "Effective cleaning for coffee machines",
        price: "19.50",
        category: "Cleaning products",
        inventory: 8,
      },
      {
        title: "Vanilla Syrup",
        description: "Natural vanilla flavor for coffee",
        price: "12.99",
        category: "Syrups",
        inventory: 20,
      },
      {
        title: "Coffee Grinder",
        description: "Professional grade coffee grinder",
        price: "89.99",
        category: "Hard Goods",
        inventory: 5,
      },
      {
        title: "Espresso Cups Set",
        description: "Set of 4 porcelain espresso cups",
        price: "24.99",
        category: "Hard Goods",
        inventory: 12,
      },
    ]

    // Convert to JSON string
    const jsonString = JSON.stringify(data, null, 2)

    // Create a blob and download
    const blob = new Blob([jsonString], { type: "application/json" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = "sample-inventory.json"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Button variant="outline" size="sm" onClick={generateSampleJson}>
      <FileType className="h-4 w-4 mr-1" />
      Sample JSON
    </Button>
  )
}

