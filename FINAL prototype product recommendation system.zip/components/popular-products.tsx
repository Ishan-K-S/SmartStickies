"use client"

import { memo } from "react"
import { Star, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { Product } from "@/lib/types"
import DetailedProductImage from "@/components/detailed-product-image"
import { useInventory } from "@/contexts/inventory-context"

interface PopularProductsProps {
  products: Product[]
  onProductSelect: (product: Product) => void
}

// Use memo to prevent unnecessary re-renders
const PopularProducts = memo(function PopularProducts({ products, onProductSelect }: PopularProductsProps) {
  // Get a mix of products from different categories - compute this once
  const popularProducts = (() => {
    const categories = ["Hard Goods", "Cleaning products", "Syrups", "Services"]
    const popularByCategory = categories.flatMap((category) => {
      return products.filter((p) => p.category === category).slice(0, 2)
    })

    return popularByCategory
  })()

  const { getInventoryCount } = useInventory()

  return (
    <div className="w-full max-w-4xl mx-auto mt-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Popular Products</h2>
        <div className="flex items-center text-primary">
          <span className="mr-1">All products</span>
          <ArrowRight className="h-4 w-4" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {popularProducts.map((product) => (
          <Card
            key={product.id}
            className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
            onClick={() => onProductSelect(product)}
          >
            <DetailedProductImage product={product} className="h-48 w-full" />
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold line-clamp-1">{product.title}</h3>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                </div>
                <div className="flex items-center bg-primary/10 px-2 py-1 rounded-full">
                  <Star className="h-3 w-3 text-primary fill-primary mr-1" />
                  <span className="text-xs font-medium">Top Pick</span>
                </div>
              </div>

              <p className="text-sm line-clamp-2 mb-3">{product.description}</p>

              <div className="flex justify-between items-center">
                <span className="font-bold">{product.price}</span>
                {(() => {
                  const inventoryCount = getInventoryCount(product.id)
                  const isInStock = inventoryCount > 0

                  return (
                    <Button
                      size="sm"
                      disabled={!isInStock}
                      onClick={(e) => {
                        e.stopPropagation()
                        onProductSelect(product)
                      }}
                    >
                      {!isInStock ? "Out of Stock" : "View Details"}
                    </Button>
                  )
                })()}
              </div>
              {(() => {
                const inventoryCount = getInventoryCount(product.id)
                if (inventoryCount > 0 && inventoryCount < 10) {
                  return <div className="mt-2 text-xs text-yellow-600 text-center">Only {inventoryCount} left</div>
                }
                return null
              })()}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
})

export default PopularProducts

