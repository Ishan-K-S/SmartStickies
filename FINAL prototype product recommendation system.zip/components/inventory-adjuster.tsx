"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useInventory } from "@/contexts/inventory-context"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Check, Plus, Minus } from "lucide-react"
import { useProducts } from "@/contexts/product-context"

export default function InventoryAdjuster() {
  const { products } = useProducts()
  const { getInventoryCount, updateInventory } = useInventory()
  const [selectedProduct, setSelectedProduct] = useState("")
  const [adjustmentAmount, setAdjustmentAmount] = useState("1")
  const [success, setSuccess] = useState(false)
  const [operation, setOperation] = useState<"add" | "subtract">("add")

  const currentInventory = selectedProduct ? getInventoryCount(selectedProduct) : 0

  const handleProductChange = (value: string) => {
    setSelectedProduct(value)
    setSuccess(false)
  }

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    if (value === "" || /^\d+$/.test(value)) {
      setAdjustmentAmount(value)
      setSuccess(false)
    }
  }

  const handleAdjustment = () => {
    if (!selectedProduct || !adjustmentAmount) return

    const amount = Number.parseInt(adjustmentAmount)
    if (isNaN(amount) || amount <= 0) return

    const newInventory = operation === "add" ? currentInventory + amount : Math.max(0, currentInventory - amount)

    updateInventory(selectedProduct, newInventory)
    setSuccess(true)

    // Reset success message after delay
    setTimeout(() => {
      setSuccess(false)
    }, 3000)
  }

  const selectedProductName = selectedProduct
    ? products.find((p) => p.id === selectedProduct)?.title || "Unknown Product"
    : ""

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Quick Inventory Adjustment</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="product">Select Product</Label>
          <Select value={selectedProduct} onValueChange={handleProductChange}>
            <SelectTrigger id="product">
              <SelectValue placeholder="Choose a product" />
            </SelectTrigger>
            <SelectContent>
              {products.map((product) => (
                <SelectItem key={product.id} value={product.id}>
                  {product.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedProduct && (
          <>
            <div className="bg-muted p-3 rounded-md text-center">
              <span className="text-sm text-muted-foreground">Current Inventory:</span>
              <div className="text-2xl font-bold">{currentInventory}</div>
              <span className="text-xs">{selectedProductName}</span>
            </div>

            <div className="space-y-2">
              <Label>Adjustment Type</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={operation === "add" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setOperation("add")}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Stock
                </Button>
                <Button
                  type="button"
                  variant={operation === "subtract" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setOperation("subtract")}
                >
                  <Minus className="h-4 w-4 mr-2" />
                  Remove Stock
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Adjustment Amount</Label>
              <Input id="amount" type="number" min="1" value={adjustmentAmount} onChange={handleAmountChange} />
            </div>

            {success && (
              <div className="bg-green-50 border border-green-200 rounded-md p-3 flex items-center text-green-700">
                <Check className="h-5 w-5 mr-2" />
                <span>
                  Inventory successfully {operation === "add" ? "increased" : "decreased"} by {adjustmentAmount}
                </span>
              </div>
            )}
          </>
        )}
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          onClick={handleAdjustment}
          disabled={!selectedProduct || !adjustmentAmount || adjustmentAmount === "0"}
        >
          {operation === "add" ? "Add to Inventory" : "Remove from Inventory"}
        </Button>
      </CardFooter>
    </Card>
  )
}

