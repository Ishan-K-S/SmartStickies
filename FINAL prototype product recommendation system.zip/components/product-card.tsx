"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import type { Product } from "@/lib/types"
import DetailedProductImage from "@/components/detailed-product-image"
import ProductDetailModal from "@/components/product-detail-modal"
import { useInventory } from "@/contexts/inventory-context"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)

  const { getInventoryCount } = useInventory()
  const inventoryCount = getInventoryCount(product.id)
  const isInStock = inventoryCount > 0

  return (
    <>
      <Card
        className="overflow-hidden flex flex-col h-full cursor-pointer transition-all hover:shadow-md"
        onClick={() => setIsModalOpen(true)}
      >
        <DetailedProductImage product={product} className="h-48 w-full" />
        <CardContent className="p-4 flex-grow">
          <div className="bg-muted rounded-md p-2 mb-3 text-xs font-medium">{product.category}</div>
          <h3 className="font-semibold text-lg mb-1 line-clamp-2">{product.title}</h3>
          <div className="text-lg font-bold mb-2 text-primary">{product.price}</div>
          <p className="text-sm text-muted-foreground line-clamp-4">{product.description}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <Button
            className="w-full"
            disabled={!isInStock}
            onClick={(e) => {
              e.stopPropagation()
              // In a real app, this would add to cart without opening the modal
              setIsModalOpen(true)
            }}
          >
            {!isInStock ? (
              "Out of Stock"
            ) : (
              <>
                <ShoppingCart className="h-4 w-4 mr-2" />
                Add to Cart
              </>
            )}
          </Button>
          {inventoryCount > 0 && inventoryCount < 10 && (
            <div className="w-full text-center mt-2 text-xs text-yellow-600">Only {inventoryCount} left</div>
          )}
        </CardFooter>
      </Card>

      <ProductDetailModal product={product} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  )
}

