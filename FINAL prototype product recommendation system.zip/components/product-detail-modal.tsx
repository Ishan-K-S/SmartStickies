"use client"

import { useState, useEffect, useCallback } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Info, Tag, Star, Coffee, ShoppingCart, Check } from "lucide-react"
import type { Product } from "@/lib/types"
import DetailedProductImage from "@/components/detailed-product-image"
import RelatedProducts from "@/components/related-products"
import { useRecentlyViewed } from "@/contexts/recently-viewed-context"
import { findRelatedProducts, getContextualRecommendations } from "@/lib/recommendation-utils"
import { coffeeProducts } from "@/lib/product-data"
import { Button } from "@/components/ui/button"
import { useCart } from "@/contexts/cart-context"
import { useInventory } from "@/contexts/inventory-context"

interface ProductDetailModalProps {
  product: Product | null
  isOpen: boolean
  onClose: () => void
}

export default function ProductDetailModal({ product, isOpen, onClose }: ProductDetailModalProps) {
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([])
  const [contextualRecommendations, setContextualRecommendations] = useState<Product[]>([])
  const { recentlyViewed, addToRecentlyViewed } = useRecentlyViewed()
  const { addToCart } = useCart()
  const { getInventoryCount } = useInventory()
  const [addedToCart, setAddedToCart] = useState(false)
  const currentInventory = product ? getInventoryCount(product.id) : 0
  // const isInStock = true // Replace with actual stock check logic

  // Memoize the product click handler to prevent recreating it on every render
  const handleProductClick = useCallback(
    (clickedProduct: Product) => {
      // Close current modal and open new one with clicked product
      onClose()
      // In a real app, you would navigate to the product page or open a new modal
      // For this demo, we'll simulate by logging to console
      console.log("Navigate to product:", clickedProduct.id)
    },
    [onClose],
  )

  const handleAddToCart = () => {
    if (product) {
      addToCart(product)
      setAddedToCart(true)
      // Optionally, reset the addedToCart state after a delay
      setTimeout(() => setAddedToCart(false), 2000)
    }
  }

  // When a product is viewed, add it to recently viewed
  useEffect(() => {
    if (product && isOpen) {
      addToRecentlyViewed(product)
    }
  }, [product, isOpen, addToRecentlyViewed])

  // Generate recommendations when product changes
  useEffect(() => {
    if (!product) return

    // Find related products
    const related = findRelatedProducts(product, coffeeProducts, 6)
    setRelatedProducts(related)

    // Get contextual recommendations
    const contextual = getContextualRecommendations(
      product,
      coffeeProducts,
      recentlyViewed.filter((p) => p.id !== product.id),
      4,
    )
    setContextualRecommendations(contextual)
  }, [product, recentlyViewed])

  if (!product) return null

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">{product.title}</DialogTitle>
          <DialogDescription className="flex items-center">
            <Badge variant="outline" className="mr-2">
              {product.category}
            </Badge>
            <div className="flex items-center text-yellow-500">
              <Star className="h-4 w-4 fill-yellow-500 mr-1" />
              <Star className="h-4 w-4 fill-yellow-500 mr-1" />
              <Star className="h-4 w-4 fill-yellow-500 mr-1" />
              <Star className="h-4 w-4 fill-yellow-500 mr-1" />
              <Star className="h-4 w-4 fill-yellow-500 mr-1" />
              <span className="text-sm text-muted-foreground ml-1">(24 reviews)</span>
            </div>
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <DetailedProductImage product={product} className="h-64 w-full rounded-md" />

          <div className="space-y-4">
            <div className="text-2xl font-bold">{product.price}</div>

            <Tabs defaultValue="description" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="description" className="flex items-center">
                  <Info className="h-4 w-4 mr-2" />
                  Details
                </TabsTrigger>
                <TabsTrigger value="features" className="flex items-center">
                  <Tag className="h-4 w-4 mr-2" />
                  Features
                </TabsTrigger>
                <TabsTrigger value="specs" className="flex items-center">
                  <Coffee className="h-4 w-4 mr-2" />
                  Specs
                </TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="pt-4">
                <p className="text-sm">{product.description}</p>
              </TabsContent>

              <TabsContent value="features" className="pt-4">
                <ul className="list-disc pl-5 text-sm space-y-1">
                  {product.category === "Hard Goods" && (
                    <>
                      <li>Premium quality coffee</li>
                      <li>Carefully selected beans</li>
                      <li>Roasted to perfection</li>
                      <li>Rich, balanced flavor profile</li>
                    </>
                  )}

                  {product.category === "Cleaning products" && (
                    <>
                      <li>Effective cleaning formula</li>
                      <li>Safe for coffee equipment</li>
                      <li>Removes coffee oils and residue</li>
                      <li>Extends machine lifespan</li>
                    </>
                  )}

                  {product.category === "Syrups" && (
                    <>
                      <li>Natural flavors</li>
                      <li>No artificial colors</li>
                      <li>Perfect sweetness level</li>
                      <li>Versatile for hot and cold drinks</li>
                    </>
                  )}

                  {product.category === "Services" && (
                    <>
                      <li>Professional expertise</li>
                      <li>Customized to your needs</li>
                      <li>Comprehensive support</li>
                      <li>Satisfaction guaranteed</li>
                    </>
                  )}
                </ul>
              </TabsContent>

              <TabsContent value="specs" className="pt-4">
                <div className="text-sm">
                  {product.category === "Hard Goods" && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Origin:</span>
                        <span>Multiple regions</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Roast Level:</span>
                        <span>Medium to Dark</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Bean Type:</span>
                        <span>Arabica, Robusta</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Weight:</span>
                        <span>1kg</span>
                      </div>
                    </div>
                  )}

                  {product.category === "Cleaning products" && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Type:</span>
                        <span>Cleaning solution</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Volume:</span>
                        <span>500ml</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Usage:</span>
                        <span>Weekly cleaning</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Compatibility:</span>
                        <span>All espresso machines</span>
                      </div>
                    </div>
                  )}

                  {product.category === "Syrups" && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Volume:</span>
                        <span>750ml</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Ingredients:</span>
                        <span>Natural flavors, sugar</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Shelf Life:</span>
                        <span>12 months</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Storage:</span>
                        <span>Room temperature</span>
                      </div>
                    </div>
                  )}

                  {product.category === "Services" && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Duration:</span>
                        <span>1-2 hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Location:</span>
                        <span>On-site</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Participants:</span>
                        <span>Up to 4 people</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Booking:</span>
                        <span>1 week in advance</span>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>

            <Button className="w-full mt-4" onClick={handleAddToCart} disabled={currentInventory === 0 || addedToCart}>
              {addedToCart ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Added to Cart
                </>
              ) : currentInventory === 0 ? (
                <>
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Out of Stock
                </>
              ) : (
                <>
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Add to Cart
                </>
              )}
            </Button>

            <div className="pt-4">
              <h3 className="text-sm font-medium mb-2">Availability</h3>
              <div className="flex items-center">
                {currentInventory > 0 ? (
                  <>
                    {currentInventory < 10 ? (
                      <>
                        <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                        <span className="text-sm">Low Stock - Only {currentInventory} left</span>
                      </>
                    ) : (
                      <>
                        <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm">In Stock - {currentInventory} available</span>
                      </>
                    )}
                  </>
                ) : (
                  <>
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                    <span className="text-sm">Out of Stock</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Recommendation components */}
        {relatedProducts.length > 0 && (
          <RelatedProducts title="Similar Products" products={relatedProducts} onProductClick={handleProductClick} />
        )}

        {contextualRecommendations.length > 0 && (
          <RelatedProducts
            title="You Might Also Like"
            products={contextualRecommendations}
            onProductClick={handleProductClick}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}

