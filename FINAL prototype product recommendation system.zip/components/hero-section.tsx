import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export default function HeroSection() {
  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-amber-900 to-amber-700 text-white">
      {/* Coffee bean pattern overlay */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern
            id="coffee-pattern"
            width="50"
            height="50"
            patternUnits="userSpaceOnUse"
            patternTransform="rotate(45)"
          >
            <path d="M10,15 Q15,5 20,15 T30,15 Q25,25 20,15" stroke="white" strokeWidth="2" fill="none" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#coffee-pattern)" />
        </svg>
      </div>

      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium Coffee Products & Services</h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">
            Discover our selection of high-quality coffee beans, equipment, and professional services for coffee
            enthusiasts and businesses.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-white text-amber-900 hover:bg-white/90">
              Shop Now
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

