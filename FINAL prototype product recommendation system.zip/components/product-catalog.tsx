"use client"

import { useEffect, useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { Product } from "@/lib/types"
import ProductCard from "@/components/product-card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle } from "lucide-react"

interface ProductCatalogProps {
  products: Product[]
}

export default function ProductCatalog({ products }: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [priceRange, setPriceRange] = useState([0, 100])
  const [newProductsAdded, setNewProductsAdded] = useState(false)

  // Get unique categories
  const categories = ["all", ...new Set(products.map((product) => product.category))]

  // Get min and max prices
  const prices = products
    .map((product) => {
      const priceStr = product.price.toString().replace("$", "")
      return Number.parseFloat(priceStr)
    })
    .filter((price) => !isNaN(price))

  const minPrice = Math.min(...prices, 0)
  const maxPrice = Math.max(...prices, 100)

  // Initialize price range
  useEffect(() => {
    setPriceRange([minPrice, maxPrice])
  }, [minPrice, maxPrice])

  // Filter products based on search query, selected category, and price range
  const filteredProducts = products.filter((product) => {
    const productPrice = Number.parseFloat(product.price.toString().replace("$", ""))

    const matchesSearch =
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory

    const matchesPrice = !isNaN(productPrice) && productPrice >= priceRange[0] && productPrice <= priceRange[1]

    return matchesSearch && matchesCategory && matchesPrice
  })

  useEffect(() => {
    // This will run whenever the products array changes
    setNewProductsAdded(true)

    // Reset the flag after 5 seconds
    const timer = setTimeout(() => {
      setNewProductsAdded(false)
    }, 5000)

    return () => clearTimeout(timer)
  }, [products.length])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="search">Search Products</Label>
          <Input
            id="search"
            placeholder="Search by name or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Filter by Category</Label>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category === "all" ? "All Categories" : category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between">
          <Label>Price Range</Label>
          <span className="text-sm text-muted-foreground">
            ${priceRange[0].toFixed(2)} - ${priceRange[1].toFixed(2)}
          </span>
        </div>
        <Slider
          defaultValue={[minPrice, maxPrice]}
          min={minPrice}
          max={maxPrice}
          step={1}
          value={priceRange}
          onValueChange={setPriceRange}
          className="py-4"
        />
      </div>

      {newProductsAdded && (
        <Alert className="mb-4 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertTitle className="text-green-600">New Products Available!</AlertTitle>
          <AlertDescription className="text-green-600">
            The product catalog has been updated with new items.
          </AlertDescription>
        </Alert>
      )}

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No products found matching your criteria.</p>
        </div>
      )}

      <div className="text-center text-sm text-muted-foreground border-t pt-4">
        Showing {filteredProducts.length} of {products.length} products
      </div>
    </div>
  )
}

