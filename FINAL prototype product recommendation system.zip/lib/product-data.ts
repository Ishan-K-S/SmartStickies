import type { Product } from "./types"

export const coffeeProducts: Product[] = [
  {
    id: "coffee-1",
    title: "Guerilla Coffee #1 - 1KG",
    description:
      "Blend Origins: - Brazil, Pulped Natural Process - Ethiopia Konga, Natural Process - Colombia, Washed Process Roast Level: - Medium to Medium Dark, Espresso Roast Taste and Flavour Profile: - Floral aroma - Dominant flavour notes of dark cherries and cocoa - Balanced body with a medium mouthfeel, medium acidity and clean finish",
    price: "$46.00",
    category: "Hard Goods",
  },
  {
    id: "coffee-2",
    title: "Guerilla Coffee #2 - 1KG",
    description:
      "Blend Origins: - Brazil, Natural Process - Congo, Natural Process - Laos, Washed Process Roast Level: - Medium Dark, Espresso Roast Taste and Flavour Profile: - Chocolatey aroma - Dominant flavour notes of dark chocolate and undertones of nuts - Full body with a medium mouthfeel, low acidity and nutty finish",
    price: "$35.60",
    category: "Hard Goods",
  },
  {
    id: "coffee-3",
    title: "Vergnano Espresso Extra - Dolce 1000",
    description:
      "Caffe Vergnano – Espresso Extra Dolce 1000 An aromatic blend of 100% Arabica coffee with a very delicate flavor, pleasant acidity, and complex fragrances. This is a blend of gourmet coffee beans with a delicate and round aroma, for the most demanding connoisseurs. Origin and Flavour Profile: - Medium and smooth finish - 100% Arabica - Delicate flavour, smooth and round body *Also available for purchase on our Lazada shop.",
    price: "$45.60",
    category: "Hard Goods",
  },
  {
    id: "coffee-4",
    title: "Vergnano Espresso Crema 800",
    description:
      "Caffe Vergnano – Crema 800 Caffe Vergnano Espresso Crema 800 beans have a soft and delicate aroma, with the sweet flavour of Central American Arabica and the intense chocolate aroma of Asian Robusta. The perfect equilibrium between aroma and body. For those who prefer their coffee delicate, fragranced and light, but full-bodied Origin and Flavour Profile: - Medium Roast - 80% Arabica, 20% Robusta - Sweet with flavour notes of chocolate *Also available for purchase on our Lazada shop.",
    price: "$41.01",
    category: "Hard Goods",
  },
  {
    id: "coffee-5",
    title: "Vergnano Espresso Classico 600",
    description:
      "Caffe Vergnano – Classico 600 A blend with a distinct character, Espresso Classico 600 has the highest percentage of Robusta coffee among all the Vergnano blends. The natural chocolate aromas and intense fragrance are obtained from the final darkening in the roasting process. Ideal for those who prefer to retain the prolonged and stronger taste of the coffee. Origin and Flavour Profile: - Dark Roast - 60% Arabica, 40% Robusta - Full, round and intense flavour *Also available for purchase on our Lazada shop.",
    price: "$33.74",
    category: "Hard Goods",
  },
  {
    id: "coffee-6",
    title: "Decaffeinato Espresso Ground (Tin)",
    description:
      "Caffe Vergnano – Decaffeinato Espresso Delicious espresso from Caffè Vergnano, without the caffeine. Ideal for anytime of the day, this coffee is full of rich and pleasant aromas. Origin and Flavour Profile: - Medium roast - 100% Arabica - Delicate flavour and full-bodied aroma with medium intensity *Also available for purchase on our Lazada shop",
    price: "$13.13",
    category: "Hard Goods",
  },
  {
    id: "coffee-7",
    title: "Powder Chocolate NO Milk",
    description:
      'Caffe Vergnano – Hot Chocolate Mix All the sweetness of the best hot chocolate to hand. Known as the "food of the gods", Caffe Vergnano\'s hot chocolate comes from the original recipe, which made the drink famous throughout Europe. In over 140 years of business, Caffe Vergnano has only ever made one serious diversification from roasting coffee: Vergnano Hot Chocolate. That is because it realised it had re-discovered something truly exceptional. *Also available for purchase on our Lazada shop',
    price: "$26.81",
    category: "Hard Goods",
  },
  {
    id: "coffee-8",
    title: "100% Arabica Bio/Organic",
    description:
      "Caffe Vergnano – Arabica Bio Organic Espresso The Caffe Vergnano Arabica Organic Bio coffee beans comes from the slow roasting coffee of the best varieties of Arabica obtained from organic farming, in harmony with nature and the local ecosystem. Great choice for a real Italian espresso with the 100% Arabica Organic Bio. Origin and Flavour Profile: - Medium roast - 100% Organic Arabica - Nutty and caramelized, aroma with medium body and smooth and sweet finish *Also available for purchase on our Lazada shop",
    price: "$45.74",
    category: "Hard Goods",
  },
  {
    id: "voucher-1",
    title: "Guerilla Coffee Cafe $10 Voucher",
    description: "Guerilla Coffee Cafe $10 Voucher",
    price: "$10.00",
    category: "Hard Goods",
  },
  {
    id: "cleaning-1",
    title: "Caffeto Espresso Clean Powder",
    description:
      "Espresso Machine Cleaning Powder - A rapidly soluble and free-rinsing formulation that removes coffee oils, grounds, and stains. - Improves flavour and aroma of espresso. - Leaves no trace of odour.",
    price: "$41.50",
    category: "Cleaning products",
  },
  {
    id: "cleaning-2",
    title: "Cafffeto MFC Blue",
    description:
      "MFC® Blue Alkaline Milk Frother Cleaner KILLS ALL COMMON BACTERIA ASSOCIATED WITH MILK Independent laboratory testing shows Cafetto® MFC® Blue kills 99.999% of Listeria when used in accordance with instructions. HIGH PERFORMANCE Provides excellent milk fat removal along with descaling of automatic milk frothers. MFC® Blue also leaves no trace of odour after rinsing. SAFE FOR YOU AND YOUR MACHINE Safe for all machine parts, MFC® Blue is listed with NSF. It has been tested, evaluated and passed the most stringent toxicology and corrosivity standards. The ingredients and formulation of the products that are NSF certified are safe, leave no harmful residues and do not cause corrosion within the coffee machine.",
    price: "$60.20",
    category: "Cleaning products",
  },
  {
    id: "cleaning-3",
    title: "Caffeto Tevo Mini Tablets",
    description:
      "TEVO® MINI Espresso Machine Cleaning Tablets - Removes coffee oils, grounds and stains, improving the taste and aroma of espresso after the machine is cleaned. - Convenient portion-controlled dose, Tevo® Mini tablets can be used to replace traditional espresso machine cleaning powders. - Phosphate and Genetically Modified Organisms (GMO) free. - Non-corrosive formulation to protect the machine. - Rapidly biodegradable meeting international standards.",
    price: "$39.60",
    category: "Cleaning products",
  },
  {
    id: "syrup-1",
    title: "Caramel VF",
    description:
      "Naked Caramel Syrup The Naked Caramel Syrup only uses natural flavours and has no added colour. The Caramel syrup gives a rich, butter caramel touch to your beverages that lingers from the first sip to the last. - Vegan Australia Certified - Gluten Free - Natural Flavours - No Added Colours",
    price: "$22.40",
    category: "Syrups",
  },
  {
    id: "syrup-2",
    title: "Hazelnut VF",
    description:
      "Naked Hazelnut Syrup The Naked Hazelnut Syrup only uses natural flavours and has no added colour. The Hazelnut syrup gives a creamy, nutty touch that is evident in your beverages. - Vegan Australia Certified - Gluten Free - Natural Flavours - No Added Colours",
    price: "$22.40",
    category: "Syrups",
  },
  {
    id: "syrup-3",
    title: "Vanilla VF",
    description:
      "Naked Vanilla Syrup The Naked Vanilla Syrup only uses natural flavours and has no added colour. The vanilla syrup brings out a rich, creamy French vanilla flavour that last from your beverage. - Vegan Australia Certified - Gluten Free - Natural Flavours - No Added Colours",
    price: "$22.40",
    category: "Syrups",
  },
  {
    id: "service-1",
    title: "Onsite Barista Calibration Service",
    description: "Onsite Barista Calibration Service",
    price: "$180.00",
    category: "Services",
  },
  {
    id: "service-2",
    title: "Ops & User Training (1.5 hours, upto 3 pax)",
    description: "Ops & User Training (1.5 hours, up to 3 pax)",
    price: "$300.00",
    category: "Services",
  },
  {
    id: "service-3",
    title: "Basic Barista Training (1 session up to 4 pax)",
    description: "Basic Barista Training (1 session up to 4 pax)",
    price: "$800.00",
    category: "Services",
  },
  {
    id: "service-4",
    title: "Beverage Menu Consultation & Development",
    description: "Beverage Menu Consultation & Development",
    price: "$500.00",
    category: "Services",
  },
  {
    id: "service-5",
    title: "Cafe setup Consultancy (from $2,000)",
    description: "Cafe setup Consultancy (from $2,000)",
    price: "$2,000.00",
    category: "Services",
  },
  {
    id: "service-6",
    title: "Technical Onsite breakdown calls for Diagnostic & Basic Repair (Weekday 930am to 530pm)",
    description: "Technical Onsite breakdown calls for Diagnostic & Basic Repair (Weekday 930am to 530pm)",
    price: "$350.00",
    category: "Services",
  },
  {
    id: "service-7",
    title: "Technical Onsite Breakdown Calls for Diagnosis & Basic Repair (Weekends / PH)",
    description: "Technical Onsite Breakdown Calls for Diagnosis & Basic Repair (Weekends / PH)",
    price: "$500.00",
    category: "Services",
  },
  {
    id: "service-8",
    title: "Technical Service Centre Basic Diagnosis & Repair (Carry-in only)",
    description: "Technical Service Centre Basic Diagnosis & Repair (Carry-in only)",
    price: "$180.00",
    category: "Services",
  },
  {
    id: "service-9",
    title: "Machine Installation or Retrieval",
    description: "Machine Installation or Retrieval on site",
    price: "$350.00",
    category: "Services",
  },
  {
    id: "service-10",
    title: "Temp Loan Machine (Basic starting from $200 per week)",
    description: "Temp Loan Machine (Basic starting from $200 per week)",
    price: "$200.00",
    category: "Services",
  },
]

