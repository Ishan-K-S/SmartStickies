// Function to generate product descriptions based on title and category
export function generateProductDescription(title: string, category: string): string {
  // Base descriptions by category
  const categoryDescriptions: Record<string, string[]> = {
    "Hard Goods": [
      "Premium quality coffee with a rich, balanced flavor profile.",
      "Carefully selected beans roasted to perfection.",
      "Exceptional coffee experience with notes of [flavor notes].",
      "Sourced from sustainable farms and roasted with care.",
      "A signature blend that delivers consistent quality in every cup.",
    ],
    "Cleaning products": [
      "Effective cleaning solution that removes coffee oils and residue.",
      "Specially formulated to maintain your coffee equipment in top condition.",
      "Professional-grade cleaner that extends the life of your coffee machines.",
      "Safe and efficient cleaning product for daily maintenance.",
      "Removes buildup and ensures the purest coffee flavor.",
    ],
    Syrups: [
      "Premium flavoring syrup made with natural ingredients.",
      "Adds rich, consistent flavor to coffee drinks and desserts.",
      "Versatile syrup perfect for hot and cold beverages.",
      "Balanced sweetness that enhances without overpowering.",
      "Professional-quality syrup used in cafes worldwide.",
    ],
    Services: [
      "Expert service delivered by trained professionals.",
      "Comprehensive solution tailored to your specific needs.",
      "Quality service that ensures optimal performance.",
      "Professional assistance to enhance your coffee experience.",
      "Specialized service with attention to detail.",
    ],
  }

  // Default to Hard Goods if category not found
  const descriptions = categoryDescriptions[category] || categoryDescriptions["Hard Goods"]

  // Select a random description
  const baseDescription = descriptions[Math.floor(Math.random() * descriptions.length)]

  // Extract potential flavor notes from the title
  let flavorNotes = "chocolate and caramel"
  if (title.toLowerCase().includes("vanilla")) flavorNotes = "vanilla and cream"
  if (title.toLowerCase().includes("caramel")) flavorNotes = "caramel and toffee"
  if (title.toLowerCase().includes("chocolate")) flavorNotes = "chocolate and cocoa"
  if (title.toLowerCase().includes("hazelnut")) flavorNotes = "hazelnut and praline"
  if (title.toLowerCase().includes("organic")) flavorNotes += " with organic certification"

  // Replace placeholder if present
  return baseDescription.replace("[flavor notes]", flavorNotes)
}

