export interface Product {
  id: string
  title: string
  description: string
  price: string | number
  category: string
  imageUrl?: string
}

export interface EmbeddingResult {
  id: string
  embedding: number[]
  product: Product
}

