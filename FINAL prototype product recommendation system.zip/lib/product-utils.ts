import type { Product } from "@/lib/types"

// Function to generate a unique product code
export function generateProductCode(product: Product, index: number): string {
  // Create a code based on category and index
  const categoryPrefix: Record<string, string> = {
    "Hard Goods": "10",
    "Cleaning products": "20",
    Syrups: "30",
    Services: "40",
  }

  const prefix = categoryPrefix[product.category] || "00"
  const sequentialNumber = String(index + 1).padStart(3, "0")

  // Combine to create a 5-digit code
  return `${prefix}${sequentialNumber}`
}

// Function to create a universal link for a product
export function createUniversalLink(productCode: string, baseUrl = "https://guerillacoffee.com"): string {
  return `${baseUrl}/product?code=${productCode}`
}

