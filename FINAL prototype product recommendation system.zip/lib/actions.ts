"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { Product } from "./types"
import { loadProducts, searchSimilarProducts } from "./product-service"

// Function to generate a webpage description for a product
export async function generateWebpage(productId: string): Promise<string> {
  try {
    // Load product data from the database or file
    const products = await loadProducts()
    const product = products.find((p) => p.id === productId)

    if (!product) {
      throw new Error(`Product with ID ${productId} not found`)
    }

    // Use OpenAI to generate the webpage content
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `
        Generate a detailed and engaging webpage description for the following product:
        
        Product Title: ${product.title}
        Product Description: ${product.description}
        Price: $${product.price}
        Category: ${product.category || "N/A"}
        
        The webpage should include:
        1. An attention-grabbing headline
        2. A detailed product description highlighting key features and benefits
        3. Suggested use cases
        4. A compelling call-to-action
        
        Format the response as HTML that can be directly used on a website.
      `,
    })

    return text
  } catch (error) {
    console.error("Error generating webpage:", error)
    throw new Error("Failed to generate webpage. Please try again.")
  }
}

// Function to get product recommendations based on user query
export async function getProductRecommendations(query: string): Promise<Product[]> {
  try {
    if (!query.trim()) {
      throw new Error("Please provide a search query")
    }

    // Find similar products using embeddings and vector search
    const similarProducts = await searchSimilarProducts(query, 5)

    if (!similarProducts.length) {
      return []
    }

    // Use LLM to refine and explain recommendations
    const productDescriptions = similarProducts
      .map((p) => `ID: ${p.id}, Title: ${p.title}, Description: ${p.description}, Price: $${p.price}`)
      .join("\n\n")

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `
        Based on the user query "${query}", I've found these potentially relevant products:
        
        ${productDescriptions}
        
        Please analyze these products and determine which ones best match the user's query.
        For each recommended product, provide a brief explanation of why it matches the query.
        
        Format your response as a JSON array with objects containing id, title, description, price, and explanation fields.
        Only include products that are truly relevant to the query.
      `,
    })

    // Parse the LLM response to get the refined recommendations
    try {
      const jsonStart = text.indexOf("[")
      const jsonEnd = text.lastIndexOf("]") + 1

      if (jsonStart >= 0 && jsonEnd > jsonStart) {
        const jsonStr = text.substring(jsonStart, jsonEnd)
        const recommendations = JSON.parse(jsonStr)

        // Map back to Product type, adding the explanation to the description
        return recommendations.map((rec: any) => ({
          id: rec.id,
          title: rec.title,
          description:
            rec.description + (rec.explanation ? `\n\nWhy this matches your search: ${rec.explanation}` : ""),
          price: rec.price,
        }))
      }
    } catch (parseError) {
      console.error("Error parsing LLM response:", parseError)
    }

    // Fallback to the original similar products if parsing fails
    return similarProducts
  } catch (error) {
    console.error("Error getting recommendations:", error)
    throw new Error("Failed to get product recommendations. Please try again.")
  }
}

