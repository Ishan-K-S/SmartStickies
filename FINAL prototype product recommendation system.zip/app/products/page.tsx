import ProductCatalog from "@/components/product-catalog"
import { useProducts } from "@/contexts/product-context"

export default function ProductsPage() {
  // This is a client component that will fetch products
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Our Products</h1>
      <ProductsContent />
    </div>
  )
}
// Client component to handle data fetching
;("use client")
function ProductsContent() {
  const { products } = useProducts()

  return <ProductCatalog products={products} />
}

