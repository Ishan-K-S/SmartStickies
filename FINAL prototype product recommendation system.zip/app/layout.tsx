import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { RecentlyViewedProvider } from "@/contexts/recently-viewed-context"
import { CartProvider } from "@/contexts/cart-context"
import { InventoryProvider } from "@/contexts/inventory-context"
import Header from "@/components/header"
import { ProductProvider } from "@/contexts/product-context"
import { NotificationProvider } from "@/contexts/notification-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Guerilla Coffee - Premium Coffee Products",
  description: "Explore our selection of premium coffee, cleaning products, syrups, and services",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ProductProvider>
          <InventoryProvider>
            <CartProvider>
              <RecentlyViewedProvider>
                <NotificationProvider>
                  <div className="flex min-h-screen flex-col">
                    <Header />
                    <main className="flex-1">{children}</main>
                  </div>
                </NotificationProvider>
              </RecentlyViewedProvider>
            </CartProvider>
          </InventoryProvider>
        </ProductProvider>
      </body>
    </html>
  )
}



import './globals.css'