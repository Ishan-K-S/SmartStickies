"use client"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Home } from "lucide-react"
import Link from "next/link"

export default function CheckoutSuccessPage() {
  // Generate a random order number
  const [orderNumber] = useState(`GC-${Math.floor(100000 + Math.random() * 900000)}`)

  // Simulate order date
  const [orderDate] = useState(new Date().toLocaleDateString())

  // Simulate items purchased from localStorage if available
  const [purchasedItems, setPurchasedItems] = useState<any[]>([])

  useEffect(() => {
    // Try to get the last purchased items from localStorage
    try {
      const lastPurchase = localStorage.getItem("lastPurchase")
      if (lastPurchase) {
        setPurchasedItems(JSON.parse(lastPurchase))
      }
    } catch (error) {
      console.error("Failed to load last purchase:", error)
    }
  }, [])

  return (
    <div className="container mx-auto py-10 px-4">
      <Card className="max-w-md mx-auto">
        <CardHeader className="text-center">
          <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-4" />
          <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-md">
            <div className="flex justify-between mb-2">
              <span className="text-muted-foreground">Order Number:</span>
              <span className="font-medium">{orderNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Date:</span>
              <span>{orderDate}</span>
            </div>
          </div>

          <p className="text-center">
            Thank you for your purchase! We've received your order and will process it right away. Your inventory has
            been updated to reflect this purchase.
          </p>

          <div className="bg-green-50 border border-green-200 rounded-md p-4 text-green-700">
            <p className="text-sm font-medium mb-2">Inventory Updated Successfully</p>
            <p className="text-xs">The inventory for the purchased items has been decreased automatically.</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/" className="w-full">
            <Button variant="default" className="w-full">
              <Home className="mr-2 h-4 w-4" />
              Return to Home
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

