"use client"

import { useState, useCallback } from "react"
import ProductSearch from "@/components/product-search"
import PopularProducts from "@/components/popular-products"
import ProductCategories from "@/components/product-categories"
import ProductDetailModal from "@/components/product-detail-modal"
import type { Product } from "@/lib/types"
import { RecentlyViewedProvider } from "@/contexts/recently-viewed-context"
import { Button } from "@/components/ui/button"
import { ShoppingBag } from "lucide-react"
import Link from "next/link"

// Add the useProducts import
import { useProducts } from "@/contexts/product-context"

export default function Home() {
  const { products } = useProducts()
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // Calculate category counts from the products context
  const categories = Array.from(new Set(products.map((p) => p.category))).map((category) => ({
    name: category,
    count: products.filter((p) => p.category === category).length,
  }))

  // Memoize handlers to prevent recreating them on every render
  const handleProductSelect = useCallback((product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }, [])

  const handleCategorySelect = useCallback((category: string) => {
    // In a real app, this would filter products by category
    console.log(`Category selected: ${category}`)
  }, [])

  const handleModalClose = useCallback(() => {
    setIsModalOpen(false)
  }, [])

  return (
    <RecentlyViewedProvider>
      <main className="min-h-screen bg-gray-50">
        {/* Hero section with prominent shop now button */}
        <div className="bg-gradient-to-r from-amber-900 to-amber-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium Coffee Products</h1>
            <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
              Discover our selection of high-quality coffee beans, equipment, and professional services.
            </p>
            <div className="flex justify-center">
              <Link href="/products">
                <Button size="lg" className="bg-white text-amber-900 hover:bg-white/90">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Shop Now
                </Button>
              </Link>
            </div>
            <Link href="/admin" className="mt-4 inline-block text-sm underline">
              Admin Area
            </Link>
          </div>
        </div>

        <div className="container mx-auto py-10 px-4">
          <ProductSearch products={products} onProductSelect={handleProductSelect} />

          <ProductCategories categories={categories} onCategorySelect={handleCategorySelect} />

          <PopularProducts products={products} onProductSelect={handleProductSelect} />

          <ProductDetailModal product={selectedProduct} isOpen={isModalOpen} onClose={handleModalClose} />
        </div>
      </main>
    </RecentlyViewedProvider>
  )
}

