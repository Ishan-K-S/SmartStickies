"use client"
import { useState, useEffect, Component } from "react"
import type React from "react"

import { useSearchParams } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProductDataPanel from "@/components/admin/product-data-panel"
import InventoryManagement from "@/components/admin/inventory-management"
import QuickProductManager from "@/components/quick-product-manager"
import InventoryAdjuster from "@/components/inventory-adjuster"
import ProductCatalog from "@/components/product-catalog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Link, Package, Plus, Grid, Key, Upload } from "lucide-react"
import AuthGuard from "@/components/admin/auth-guard"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useProducts } from "@/contexts/product-context"

// Import the simplified component
import InventoryUploadSimple from "@/components/admin/inventory-upload-simple"

// Add this class before the AdminPage component
class ErrorBoundary extends Component<{ children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 border border-red-200 bg-red-50 rounded-md">
          <h3 className="text-lg font-medium text-red-800 mb-2">Something went wrong</h3>
          <p className="text-red-600">There was an error loading this component. Please try refreshing the page.</p>
          <button
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
            onClick={() => this.setState({ hasError: false })}
          >
            Try again
          </button>
        </div>
      )
    }

    return this.props.children
  }
}

export default function AdminPage() {
  const { products } = useProducts()
  const searchParams = useSearchParams()
  const tabParam = searchParams.get("tab")
  const [activeTab, setActiveTab] = useState("dashboard")

  // Set the active tab based on URL parameter if present
  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  return (
    <div className="container mx-auto py-10 px-4">
      <AuthGuard>
        <h1 className="text-3xl font-bold mb-8 text-center">Guerilla Coffee Admin</h1>

        <Alert className="mb-6">
          <Key className="h-4 w-4" />
          <AlertTitle>Admin Area Key</AlertTitle>
          <AlertDescription>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="flex items-center gap-2">
                <Package className="h-4 w-4 text-blue-500" />
                <span>Inventory Management - Manage stock levels</span>
              </div>
              <div className="flex items-center gap-2">
                <Link className="h-4 w-4 text-green-500" />
                <span>Product Links - Generate universal product links</span>
              </div>
              <div className="flex items-center gap-2">
                <Grid className="h-4 w-4 text-purple-500" />
                <span>Product Catalog - View all products</span>
              </div>
              <div className="flex items-center gap-2">
                <Plus className="h-4 w-4 text-orange-500" />
                <span>Quick Manager - Add products and adjust inventory</span>
              </div>
              <div className="flex items-center gap-2">
                <Upload className="h-4 w-4 text-indigo-500" />
                <span>Bulk Upload - Import inventory in bulk</span>
              </div>
            </div>
          </AlertDescription>
        </Alert>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
            <TabsTrigger value="dashboard" className="flex items-center">
              <Package className="mr-2 h-4 w-4" />
              Inventory
            </TabsTrigger>
            <TabsTrigger value="product-links" className="flex items-center">
              <Link className="mr-2 h-4 w-4" />
              Product Links
            </TabsTrigger>
            <TabsTrigger value="catalog" className="flex items-center">
              <Grid className="mr-2 h-4 w-4" />
              Catalog
            </TabsTrigger>
            <TabsTrigger value="quick-manager" className="flex items-center">
              <Plus className="mr-2 h-4 w-4" />
              Quick Manager
            </TabsTrigger>
            <TabsTrigger value="bulk-upload" className="flex items-center">
              <Upload className="mr-2 h-4 w-4" />
              Bulk Upload
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <InventoryManagement />
          </TabsContent>

          <TabsContent value="product-links" className="mt-6">
            <ProductDataPanel />
          </TabsContent>

          <TabsContent value="catalog" className="mt-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold mb-6">Product Catalog</h2>
              <ProductCatalog products={products} />
            </div>
          </TabsContent>

          <TabsContent value="quick-manager" className="mt-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold mb-6">Quick Product Manager</h2>

              <Tabs defaultValue="add-product" className="w-full mb-8">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="add-product">Add Product</TabsTrigger>
                  <TabsTrigger value="adjust-inventory">Adjust Inventory</TabsTrigger>
                </TabsList>

                <TabsContent value="add-product" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>How It Works</CardTitle>
                        <CardDescription>Quickly add products and manage inventory</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h3 className="font-medium">1. Add Product Details</h3>
                          <p className="text-sm text-muted-foreground">
                            Enter the product name, description, price, category, and initial stock.
                          </p>
                        </div>

                        <div>
                          <h3 className="font-medium">2. Generate Product Link</h3>
                          <p className="text-sm text-muted-foreground">
                            The system will automatically generate a unique product code and link.
                          </p>
                        </div>

                        <div>
                          <h3 className="font-medium">3. Inventory Management</h3>
                          <p className="text-sm text-muted-foreground">
                            Initial stock will be added to inventory. When customers purchase the product, inventory
                            will automatically decrease.
                          </p>
                        </div>

                        <div>
                          <h3 className="font-medium">4. Share Product Link</h3>
                          <p className="text-sm text-muted-foreground">
                            Copy and share the generated link to allow customers to directly access the product page.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <QuickProductManager />
                  </div>
                </TabsContent>

                <TabsContent value="adjust-inventory" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>Inventory Management</CardTitle>
                        <CardDescription>Quickly adjust inventory levels</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h3 className="font-medium">1. Select a Product</h3>
                          <p className="text-sm text-muted-foreground">
                            Choose the product you want to adjust inventory for.
                          </p>
                        </div>

                        <div>
                          <h3 className="font-medium">2. Choose Operation</h3>
                          <p className="text-sm text-muted-foreground">Select whether to add or remove stock.</p>
                        </div>

                        <div>
                          <h3 className="font-medium">3. Enter Amount</h3>
                          <p className="text-sm text-muted-foreground">Specify how many units to add or remove.</p>
                        </div>

                        <div>
                          <h3 className="font-medium">4. Apply Changes</h3>
                          <p className="text-sm text-muted-foreground">The inventory will be updated immediately.</p>
                        </div>
                      </CardContent>
                    </Card>

                    <InventoryAdjuster />
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </TabsContent>

          {/* Replace the TabsContent for "bulk-upload" with this: */}
          <TabsContent value="bulk-upload" className="mt-6">
            <InventoryUploadSimple />
          </TabsContent>
        </Tabs>
      </AuthGuard>
    </div>
  )
}

