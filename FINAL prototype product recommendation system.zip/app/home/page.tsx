"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function HomePage() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the main page after a short delay
    const redirectTimer = setTimeout(() => {
      router.push("/")
    }, 500) // Short delay for a smoother experience

    return () => clearTimeout(redirectTimer)
  }, [router])

  return (
    <div className="container mx-auto py-20 px-4 flex items-center justify-center min-h-[50vh]">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center justify-center p-6 text-center">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <h1 className="text-2xl font-bold mb-2">Redirecting to Home</h1>
          <p className="text-muted-foreground">Taking you back to the main page...</p>
        </CardContent>
      </Card>
    </div>
  )
}

