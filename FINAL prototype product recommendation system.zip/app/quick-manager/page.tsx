"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function QuickManagerPage() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the admin page with quick manager tab
    router.push("/admin?tab=quick-manager")
  }, [router])

  return (
    <div className="container mx-auto py-20 px-4 flex items-center justify-center min-h-[50vh]">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center justify-center p-6 text-center">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <h1 className="text-2xl font-bold mb-2">Redirecting to Admin</h1>
          <p className="text-muted-foreground">Taking you to the centralized admin page...</p>
        </CardContent>
      </Card>
    </div>
  )
}

