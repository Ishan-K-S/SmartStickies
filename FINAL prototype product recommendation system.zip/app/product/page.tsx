"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ShoppingCart, ArrowLeft, Check } from "lucide-react"
import DetailedProductImage from "@/components/detailed-product-image"
import { coffeeProducts } from "@/lib/product-data"
import { useCart } from "@/contexts/cart-context"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { useInventory } from "@/contexts/inventory-context"

export default function ProductPage() {
  const searchParams = useSearchParams()
  const productCode = searchParams.get("code")
  const [product, setProduct] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)
  const [addedToCart, setAddedToCart] = useState(false)
  const { addToCart } = useCart()
  const { getInventoryCount } = useInventory()

  useEffect(() => {
    // Simulate API call to fetch product by code
    setLoading(true)

    setTimeout(() => {
      if (productCode) {
        // In a real app, this would be an API call
        // For now, we'll find the product by matching the code pattern
        const categoryPrefix = productCode.substring(0, 2)
        const sequentialNumber = Number.parseInt(productCode.substring(2, 5))

        let category = ""
        switch (categoryPrefix) {
          case "10":
            category = "Hard Goods"
            break
          case "20":
            category = "Cleaning products"
            break
          case "30":
            category = "Syrups"
            break
          case "40":
            category = "Services"
            break
        }

        // Find the product with matching category and index
        const matchingProducts = coffeeProducts.filter((p) => p.category === category)
        const foundProduct = matchingProducts[sequentialNumber - 1]

        setProduct(foundProduct || null)
      }
      setLoading(false)
    }, 500)
  }, [productCode])

  const handleAddToCart = () => {
    if (product) {
      addToCart(product)
      setAddedToCart(true)
      setTimeout(() => setAddedToCart(false), 2000)
    }
  }

  const inventoryCount = product ? getInventoryCount(product.id) : 0
  const isInStock = inventoryCount > 0

  if (loading) {
    return (
      <div className="container mx-auto py-10 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-24" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="h-96 w-full rounded-md" />

            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-4 w-5/6" />
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-10 w-full mt-8" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto py-10 px-4">
        <Card className="max-w-md mx-auto text-center p-8">
          <CardContent className="space-y-4">
            <h1 className="text-2xl font-bold">Product Not Found</h1>
            <p>The product you're looking for doesn't exist or has been removed.</p>
            <Link href="/">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Return to Homepage
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="text-sm text-muted-foreground hover:underline inline-flex items-center">
            <ArrowLeft className="mr-1 h-3 w-3" />
            Back to Products
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <DetailedProductImage product={product} className="h-96 w-full rounded-md" />

          <div className="space-y-4">
            <h1 className="text-3xl font-bold">{product.title}</h1>

            <div className="flex items-center gap-2">
              <Badge>{product.category}</Badge>
              <Badge variant="outline">Product Code: {productCode}</Badge>
            </div>

            <div className="text-2xl font-bold">{product.price}</div>

            <div className="flex items-center gap-2">
              {inventoryCount > 0 ? (
                <>
                  {inventoryCount < 10 ? (
                    <>
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span className="text-sm">Low Stock - Only {inventoryCount} left</span>
                    </>
                  ) : (
                    <>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="text-sm">In Stock ({inventoryCount} available)</span>
                    </>
                  )}
                </>
              ) : (
                <>
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-sm">Out of Stock</span>
                </>
              )}
            </div>

            <p className="text-muted-foreground">{product.description}</p>

            <Button className="w-full mt-4" onClick={handleAddToCart} disabled={!isInStock || addedToCart}>
              {addedToCart ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Added to Cart
                </>
              ) : !isInStock ? (
                <>
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Out of Stock
                </>
              ) : (
                <>
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Add to Cart
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

