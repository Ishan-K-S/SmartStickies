"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { CheckCircle, AlertCircle, X } from "lucide-react"

type NotificationType = "success" | "error" | "info" | "warning"

interface Notification {
  id: string
  type: NotificationType
  message: string
  duration?: number
}

interface NotificationContextType {
  notifications: Notification[]
  addNotification: (type: NotificationType, message: string, duration?: number) => void
  removeNotification: (id: string) => void
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([])

  const addNotification = (type: NotificationType, message: string, duration = 5000) => {
    const id = Math.random().toString(36).substring(2, 9)
    setNotifications((prev) => [...prev, { id, type, message, duration }])
  }

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  return (
    <NotificationContext.Provider value={{ notifications, addNotification, removeNotification }}>
      {children}
      <NotificationDisplay />
    </NotificationContext.Provider>
  )
}

export function useNotification() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error("useNotification must be used within a NotificationProvider")
  }
  return context
}

function NotificationDisplay() {
  const { notifications, removeNotification } = useNotification()

  // Auto-remove notifications after their duration
  useEffect(() => {
    notifications.forEach((notification) => {
      if (notification.duration) {
        const timer = setTimeout(() => {
          removeNotification(notification.id)
        }, notification.duration)
        return () => clearTimeout(timer)
      }
    })
  }, [notifications, removeNotification])

  if (notifications.length === 0) return null

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`
            p-4 rounded-md shadow-md flex items-start gap-3 animate-in slide-in-from-right-5 duration-300
            ${notification.type === "success" ? "bg-green-50 border border-green-200 text-green-800" : ""}
            ${notification.type === "error" ? "bg-red-50 border border-red-200 text-red-800" : ""}
            ${notification.type === "info" ? "bg-blue-50 border border-blue-200 text-blue-800" : ""}
            ${notification.type === "warning" ? "bg-yellow-50 border border-yellow-200 text-yellow-800" : ""}
          `}
        >
          {notification.type === "success" && <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />}
          {notification.type === "error" && <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />}
          {notification.type === "info" && <AlertCircle className="h-5 w-5 text-blue-500 flex-shrink-0" />}
          {notification.type === "warning" && <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0" />}

          <div className="flex-1">{notification.message}</div>

          <button onClick={() => removeNotification(notification.id)} className="text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  )
}

