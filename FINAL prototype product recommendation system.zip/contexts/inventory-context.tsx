"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { coffeeProducts } from "@/lib/product-data"

interface InventoryItem {
  productId: string
  count: number
}

interface InventoryContextType {
  inventory: InventoryItem[]
  getInventoryCount: (productId: string) => number
  updateInventory: (productId: string, count: number) => void
  decrementInventory: (productId: string, amount?: number) => void
  incrementInventory: (productId: string, amount?: number) => void
  isInStock: (productId: string) => boolean
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined)

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [initialized, setInitialized] = useState(false)

  // Initialize inventory with default values
  useEffect(() => {
    if (!initialized) {
      try {
        // Try to load from localStorage first
        const savedInventory = localStorage.getItem("inventory")

        if (savedInventory) {
          setInventory(JSON.parse(savedInventory))
        } else {
          // Initialize with default values if not in localStorage
          const defaultInventory = coffeeProducts.map((product) => ({
            productId: product.id,
            // Random inventory between 5 and 20 for each product
            count: Math.floor(Math.random() * 16) + 5,
          }))
          setInventory(defaultInventory)
        }
      } catch (error) {
        console.error("Failed to initialize inventory:", error)
        // Fallback to default values
        const defaultInventory = coffeeProducts.map((product) => ({
          productId: product.id,
          count: 10,
        }))
        setInventory(defaultInventory)
      }

      setInitialized(true)
    }
  }, [initialized])

  // Save inventory to localStorage when it changes
  useEffect(() => {
    if (initialized) {
      try {
        localStorage.setItem("inventory", JSON.stringify(inventory))
      } catch (error) {
        console.error("Failed to save inventory:", error)
      }
    }
  }, [inventory, initialized])

  const getInventoryCount = useCallback(
    (productId: string) => {
      const item = inventory.find((item) => item.productId === productId)
      return item ? item.count : 0
    },
    [inventory],
  )

  const updateInventory = useCallback((productId: string, count: number) => {
    setInventory((prevInventory) => {
      const itemIndex = prevInventory.findIndex((item) => item.productId === productId)

      if (itemIndex >= 0) {
        // Update existing item
        const updatedInventory = [...prevInventory]
        updatedInventory[itemIndex] = { ...updatedInventory[itemIndex], count }
        return updatedInventory
      } else {
        // Add new item
        return [...prevInventory, { productId, count }]
      }
    })
  }, [])

  const decrementInventory = useCallback((productId: string, amount = 1) => {
    setInventory((prevInventory) => {
      return prevInventory.map((item) => {
        if (item.productId === productId) {
          const newCount = Math.max(0, item.count - amount)
          return { ...item, count: newCount }
        }
        return item
      })
    })
  }, [])

  const incrementInventory = useCallback((productId: string, amount = 1) => {
    setInventory((prevInventory) => {
      const itemIndex = prevInventory.findIndex((item) => item.productId === productId)

      if (itemIndex >= 0) {
        // Update existing item
        const updatedInventory = [...prevInventory]
        updatedInventory[itemIndex] = {
          ...updatedInventory[itemIndex],
          count: updatedInventory[itemIndex].count + amount,
        }
        return updatedInventory
      } else {
        // Add new item
        return [...prevInventory, { productId, count: amount }]
      }
    })
  }, [])

  // Update the isInStock function to be more explicit
  const isInStock = useCallback(
    (productId: string) => {
      return getInventoryCount(productId) > 0
    },
    [getInventoryCount],
  )

  return (
    <InventoryContext.Provider
      value={{
        inventory,
        getInventoryCount,
        updateInventory,
        decrementInventory,
        incrementInventory,
        isInStock,
      }}
    >
      {children}
    </InventoryContext.Provider>
  )
}

export function useInventory() {
  const context = useContext(InventoryContext)
  if (context === undefined) {
    throw new Error("useInventory must be used within an InventoryProvider")
  }
  return context
}

