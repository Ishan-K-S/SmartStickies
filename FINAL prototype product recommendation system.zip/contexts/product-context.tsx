"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { coffeeProducts as initialCoffeeProducts } from "@/lib/product-data"
import type { Product } from "@/lib/types"

// Update the interface:
interface ProductContextType {
  products: Product[]
  addProduct: (product: Product, onAdd?: () => void) => void
  getProducts: () => Product[]
}

const ProductContext = createContext<ProductContextType | undefined>(undefined)

export function ProductProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>(initialCoffeeProducts)

  // Load products from localStorage on mount
  useEffect(() => {
    try {
      const savedProducts = localStorage.getItem("coffeeProducts")
      if (savedProducts) {
        setProducts(JSON.parse(savedProducts))
      }
    } catch (error) {
      console.error("Failed to load products:", error)
    }
  }, [])

  // Save products to localStorage when they change
  useEffect(() => {
    try {
      localStorage.setItem("coffeeProducts", JSON.stringify(products))
    } catch (error) {
      console.error("Failed to save products:", error)
    }
  }, [products])

  // Update the function:
  const addProduct = (product: Product, onAdd?: () => void) => {
    // Check if product with this ID already exists
    setProducts((prevProducts) => {
      const exists = prevProducts.some((p) => p.id === product.id)
      if (exists) {
        // Update the existing product
        return prevProducts.map((p) => (p.id === product.id ? { ...p, ...product } : p))
      } else {
        // Add the new product
        if (onAdd) onAdd()
        return [...prevProducts, product]
      }
    })

    // Force a localStorage update to ensure persistence
    setTimeout(() => {
      try {
        localStorage.setItem("coffeeProducts", JSON.stringify(products))
      } catch (error) {
        console.error("Failed to save products:", error)
      }
    }, 100)
  }

  const getProducts = () => products

  return <ProductContext.Provider value={{ products, addProduct, getProducts }}>{children}</ProductContext.Provider>
}

export function useProducts() {
  const context = useContext(ProductContext)
  if (context === undefined) {
    throw new Error("useProducts must be used within a ProductProvider")
  }
  return context
}

