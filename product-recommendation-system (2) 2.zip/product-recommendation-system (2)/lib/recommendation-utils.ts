import type { Product } from "@/lib/types"

/**
 * Calculate similarity score between two products
 * Higher score means more similar
 */
export function calculateProductSimilarity(productA: Product, productB: Product): number {
  const categoryMatch = productA.category === productB.category ? 1 : 0;
  const priceDifference = Math.abs(productA.price - productB.price);
  const priceScore = priceDifference <= 10 ? 1 : 0;

  const wordsA = new Set(productA.title.split(' ').concat(productA.description.split(' ')));
  const wordsB = new Set(productB.title.split(' ').concat(productB.description.split(' ')));
  const commonWords = [...wordsA].filter(word => wordsB.has(word));

  return categoryMatch + priceScore + commonWords.length / 10;
}

export function getContextualRecommendations(recentProducts: Product[], currentProduct: Product): Product[] {
  const recommendations = new Set<Product>();

  recentProducts.forEach(recent => {
    if (calculateProductSimilarity(recent, currentProduct) > 1) {
      recommendations.add(recent);
    }
  });

  return [...recommendations];
}


/**
 * Find related products based on similarity
 */
export function findRelatedProducts(currentProduct: Product, allProducts: Product[], limit = 3): Product[] {
  // Calculate similarity scores
  const productsWithScores = allProducts
    .map((product) => ({
      product,
      score: calculateProductSimilarity(currentProduct, product),
    }))
    .filter((item) => item.score > 0) // Only include products with some similarity
    .sort((a, b) => b.score - a.score) // Sort by score (highest first)

  // Return top N products
  return productsWithScores.slice(0, limit).map((item) => item.product)
}

/**
 * Find complementary products that pair well with the current product
 */
export function findComplementaryProducts(currentProduct: Product, allProducts: Product[], limit = 2): Product[] {
  // For coffee products, recommend cleaning products or syrups
  if (currentProduct.category === "Hard Goods") {
    return allProducts
      .filter((p) => p.id !== currentProduct.id && (p.category === "Cleaning products" || p.category === "Syrups"))
      .slice(0, limit)
  }

  // For cleaning products, recommend coffee products
  if (currentProduct.category === "Cleaning products") {
    return allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Hard Goods").slice(0, limit)
  }

  // For syrups, recommend coffee products
  if (currentProduct.category === "Syrups") {
    return allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Hard Goods").slice(0, limit)
  }

  // For services, recommend other services or coffee products
  if (currentProduct.category === "Services") {
    const otherServices = allProducts.filter((p) => p.id !== currentProduct.id && p.category === "Services").slice(0, 1)

    const coffeeProducts = allProducts.filter((p) => p.category === "Hard Goods").slice(0, limit - otherServices.length)

    return [...otherServices, ...coffeeProducts]
  }

  // Default fallback
  return allProducts.filter((p) => p.id !== currentProduct.id).slice(0, limit)
}

/**
 * Create a context-aware recommendation based on multiple factors
 */
export function getContextualRecommendations(
  currentProduct: Product,
  allProducts: Product[],
  recentlyViewed: Product[] = [],
  limit = 4,
): Product[] {
  // Get products similar to recently viewed items
  const recentBasedRecs =
    recentlyViewed.length > 0
      ? recentlyViewed.flatMap((p) => findRelatedProducts(p, allProducts, 2)).filter((p) => p.id !== currentProduct.id)
      : []

  // Get products similar to current product
  const similarProducts = findRelatedProducts(currentProduct, allProducts, limit)

  // Combine and deduplicate
  const combinedRecs = [...recentBasedRecs, ...similarProducts]
  const uniqueRecs = Array.from(new Map(combinedRecs.map((p) => [p.id, p])).values())

  return uniqueRecs.slice(0, limit)
}

