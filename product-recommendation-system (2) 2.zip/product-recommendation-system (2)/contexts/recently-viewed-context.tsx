"use client"

import React, { createContext, useContext, useState, useEffect, useCallback } from "react"
import type { Product } from "@/lib/types"

interface RecentlyViewedContextType {
  recentlyViewed: Product[]
  addToRecentlyViewed: (product: Product) => void
  clearRecentlyViewed: () => void
}

const RecentlyViewedContext = createContext<RecentlyViewedContextType | undefined>(undefined)

export function RecentlyViewedProvider({ children }: { children: React.ReactNode }) {
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([])

  // Load from localStorage on mount only
  useEffect(() => {
    try {
      const saved = localStorage.getItem("recentlyViewed")
      if (saved) {
        setRecentlyViewed(JSON.parse(saved))
      }
    } catch (error) {
      console.error("Failed to load recently viewed products:", error)
    }
  }, []) // Empty dependency array - only run once on mount

  // Save to localStorage when updated, but debounce to prevent excessive writes
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem("recentlyViewed", JSON.stringify(recentlyViewed))
      } catch (error) {
        console.error("Failed to save recently viewed products:", error)
      }
    }, 300)

    return () => clearTimeout(timer)
  }, [recentlyViewed])

  // Memoize the function to prevent recreating it on every render
  const addToRecentlyViewed = useCallback((product: Product) => {
    setRecentlyViewed((prev) => {
      // Check if product already exists
      if (prev.some((p) => p.id === product.id)) {
        return prev // Return the same array if product already exists
      }

      // Add to beginning and limit to 10 items
      return [product, ...prev].slice(0, 10)
    })
  }, [])

  const clearRecentlyViewed = useCallback(() => {
    setRecentlyViewed([])
  }, [])

  // Memoize the context value to prevent unnecessary re-renders
  const contextValue = React.useMemo(
    () => ({
      recentlyViewed,
      addToRecentlyViewed,
      clearRecentlyViewed,
    }),
    [recentlyViewed, addToRecentlyViewed, clearRecentlyViewed],
  )

  return <RecentlyViewedContext.Provider value={contextValue}>{children}</RecentlyViewedContext.Provider>
}

export function useRecentlyViewed() {
  const context = useContext(RecentlyViewedContext)
  if (context === undefined) {
    throw new Error("useRecentlyViewed must be used within a RecentlyViewedProvider")
  }
  return context
}

