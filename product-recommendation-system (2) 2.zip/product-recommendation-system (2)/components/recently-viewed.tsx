"use client"

import type { Product } from "@/lib/types"
import DetailedProductImage from "@/components/detailed-product-image"

interface RecentlyViewedProps {
  products: Product[]
  onProductClick: (product: Product) => void
}

export default function RecentlyViewed({ products, onProductClick }: RecentlyViewedProps) {
  if (products.length === 0) return null

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold mb-3">Recently Viewed</h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {products.map((product) => (
          <div
            key={product.id}
            className="border rounded-md overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => onProductClick(product)}
          >
            <DetailedProductImage product={product} className="h-24 w-full" />
            <div className="p-2">
              <h4 className="font-medium text-xs line-clamp-1">{product.title}</h4>
              <p className="font-bold text-xs mt-1">{product.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

