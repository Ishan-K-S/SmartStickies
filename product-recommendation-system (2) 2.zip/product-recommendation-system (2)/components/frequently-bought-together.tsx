"use client"

import React from "react"

import type { Product } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Plus } from "lucide-react"
import DetailedProductImage from "@/components/detailed-product-image"

interface FrequentlyBoughtTogetherProps {
  mainProduct: Product
  complementaryProducts: Product[]
  onProductClick: (product: Product) => void
}

export default function FrequentlyBoughtTogether({
  mainProduct,
  complementaryProducts,
  onProductClick,
}: FrequentlyBoughtTogetherProps) {
  if (complementaryProducts.length === 0) return null

  // Calculate total price
  const calculateTotal = () => {
    const mainPrice =
      typeof mainProduct.price === "string"
        ? Number.parseFloat(mainProduct.price.replace(/[^0-9.]/g, ""))
        : mainProduct.price

    const complementaryTotal = complementaryProducts.reduce((sum, product) => {
      const price =
        typeof product.price === "string" ? Number.parseFloat(product.price.replace(/[^0-9.]/g, "")) : product.price
      return sum + price
    }, 0)

    return `$${(mainPrice + complementaryTotal).toFixed(2)}`
  }

  return (
    <div className="mt-6 border rounded-md p-4">
      <h3 className="text-lg font-semibold mb-4">Frequently Bought Together</h3>

      <div className="flex flex-col md:flex-row items-center gap-2 mb-4">
        <div className="w-full md:w-1/3 cursor-pointer" onClick={() => onProductClick(mainProduct)}>
          <DetailedProductImage product={mainProduct} className="h-32 w-full" />
          <div className="text-center mt-2">
            <p className="font-medium text-sm">{mainProduct.title}</p>
            <p className="font-bold text-sm">{mainProduct.price}</p>
          </div>
        </div>

        {complementaryProducts.map((product, index) => (
          <React.Fragment key={product.id}>
            <Plus className="hidden md:block" />
            <div className="w-full md:w-1/3 cursor-pointer" onClick={() => onProductClick(product)}>
              <DetailedProductImage product={product} className="h-32 w-full" />
              <div className="text-center mt-2">
                <p className="font-medium text-sm">{product.title}</p>
                <p className="font-bold text-sm">{product.price}</p>
              </div>
            </div>
          </React.Fragment>
        ))}
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Total price:</p>
          <p className="text-xl font-bold">{calculateTotal()}</p>
        </div>

        <Button className="w-full md:w-auto">
          <ShoppingCart className="h-4 w-4 mr-2" />
          Add All to Cart
        </Button>
      </div>
    </div>
  )
}

