"use client"

import { useState, memo } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Product } from "@/lib/types"
import { Button } from "@/components/ui/button"
import DetailedProductImage from "@/components/detailed-product-image"

interface RelatedProductsProps {
  title: string
  products: Product[]
  onProductClick: (product: Product) => void
}

// Use memo to prevent unnecessary re-renders
const RelatedProducts = memo(function RelatedProducts({ title, products, onProductClick }: RelatedProductsProps) {
  const [scrollPosition, setScrollPosition] = useState(0)

  const scrollLeft = () => {
    setScrollPosition(Math.max(0, scrollPosition - 1))
  }

  const scrollRight = () => {
    setScrollPosition(Math.min(products.length - 1, scrollPosition + 1))
  }

  if (products.length === 0) return null

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={scrollLeft}
            disabled={scrollPosition === 0}
            className="h-8 w-8"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={scrollRight}
            disabled={scrollPosition >= products.length - 1}
            className="h-8 w-8"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="relative overflow-hidden">
        <div
          className="flex transition-transform duration-300 ease-in-out"
          style={{ transform: `translateX(-${scrollPosition * 100}%)` }}
        >
          {products.map((product) => (
            <div
              key={product.id}
              className="min-w-full sm:min-w-[50%] md:min-w-[33.333%] p-2 cursor-pointer"
              onClick={() => onProductClick(product)}
            >
              <div className="border rounded-md overflow-hidden hover:shadow-md transition-shadow">
                <DetailedProductImage product={product} className="h-32 w-full" />
                <div className="p-3">
                  <h4 className="font-medium text-sm line-clamp-1">{product.title}</h4>
                  <p className="text-sm text-muted-foreground line-clamp-1">{product.category}</p>
                  <p className="font-bold text-sm mt-1">{product.price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
})

export default RelatedProducts

