"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { generateWebpage } from "@/lib/actions"

export default function WebpageGenerator() {
  const [productId, setProductId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const generatedContent = await generateWebpage(productId)
      setResult(generatedContent)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate webpage")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="productId">Product ID</Label>
          <Input
            id="productId"
            placeholder="Enter product ID (e.g., P12345)"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            required
          />
        </div>
        <Button type="submit" disabled={isLoading || !productId}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Webpage"
          )}
        </Button>
      </form>

      {error && <div className="p-4 bg-red-50 text-red-600 rounded-md">{error}</div>}

      {result && (
        <Card className="mt-6">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-2">Generated Webpage:</h3>
            <div className="p-4 bg-muted rounded-md whitespace-pre-wrap">{result}</div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

